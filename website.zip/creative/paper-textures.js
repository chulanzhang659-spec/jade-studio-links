import {CATEGORIES} from './categories.mjs?v=cover1';
import * as THREE from './assets/vendor/three.module.min.js';

function rng(seed){return()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};}
function tornPath(ctx,random){
 ctx.beginPath();ctx.moveTo(0,5);
 for(let x=0;x<=512;x+=8)ctx.lineTo(x,2+random()*7);
 for(let y=0;y<=320;y+=8)ctx.lineTo(510-random()*4,y);
 for(let x=512;x>=0;x-=8)ctx.lineTo(x,318-random()*7);
 for(let y=320;y>=0;y-=8)ctx.lineTo(random()*4,y);
 ctx.closePath();
}
function grain(ctx,random){
 for(let i=0;i<11000;i++){ctx.fillStyle=random()>.5?'rgba(54,44,20,.055)':'rgba(255,253,232,.10)';ctx.fillRect(random()*512,random()*320,random()*1.8+.4,.6);}
}
function imageFit(ctx,image,x,y,w,h,cover=false,crop=[0,0,1,1]){
 const [cx,cy,cw,ch]=crop,sw=image.width*cw,sh=image.height*ch,s=cover?Math.max(w/sw,h/sh):Math.min(w/sw,h/sh);
 ctx.save();ctx.beginPath();ctx.rect(x,y,w,h);ctx.clip();ctx.drawImage(image,cx*image.width,cy*image.height,sw,sh,x+(w-sw*s)/2,y+(h-sh*s)/2,sw*s,sh*s);ctx.restore();
}
function handwritten(ctx,text,x,y,size=28,angle=-.07){if(ctx.canvas.dataset.text==='false')return;ctx.save();ctx.translate(x,y);ctx.rotate(angle);ctx.fillStyle='#353629';ctx.font=size+'px "La Belle Aurore",cursive';ctx.fillText(text,0,0);ctx.restore();}
function type(ctx,text,x,y,size=11){if(ctx.canvas.dataset.text==='false')return;ctx.fillStyle='#333729';ctx.font=size+'px "Special Elite",monospace';ctx.fillText(text,x,y);}
function tape(ctx,x,y,w,angle){ctx.save();ctx.translate(x,y);ctx.rotate(angle);ctx.fillStyle='#92977788';ctx.beginPath();ctx.moveTo(0,2);for(let i=0;i<=w;i+=7)ctx.lineTo(i,(i%14)?1:4);ctx.lineTo(w,27);ctx.lineTo(0,25);ctx.closePath();ctx.fill();ctx.restore();}

export function paperCanvas(images,index,{text=true}={}){
 const canvas=document.createElement('canvas');canvas.width=768;canvas.height=480;canvas.dataset.text=String(text);
 const ctx=canvas.getContext('2d');ctx.scale(1.5,1.5);
 const random=rng(index*731+41),kind=index%4;
 const notes=['a line worth keeping','fall softly','notes on movement','a little undone','in green, always','follow the drape','made by hand','the quiet details','softness / structure','leave room to move','from the atelier','a study in feeling'];
 if(kind===0){
  ctx.fillStyle='#20271c';ctx.fillRect(0,0,512,320);ctx.fillStyle='#c3c8ac';ctx.fillRect(19,24,474,272);
  const crop=index===4?[.2,.05,.65,.5]:index===8?[.22,.3,.6,.6]:[0,0,1,1];
  imageFit(ctx,images[0],19,24,474,272,index!==0,crop);
  ctx.fillStyle='#d9d7bc';for(let y=24;y<294;y+=27){ctx.fillRect(5,y,6,12);ctx.fillRect(501,y,6,12);}
  if(text){ctx.font='8px "Special Elite",monospace';ctx.fillText('JADE / ARCHIVE '+String(index+1).padStart(2,'0'),22,15);ctx.fillText('A FASHION STUDY',22,310);}
 }else{
  ctx.save();tornPath(ctx,random);ctx.clip();ctx.fillStyle=kind===2?'#e2dcc5':'#e9e3d1';ctx.fillRect(0,0,512,320);
  const wash=ctx.createLinearGradient(0,0,512,320);wash.addColorStop(0,'#fff8db33');wash.addColorStop(1,'#7d744b1c');ctx.fillStyle=wash;ctx.fillRect(0,0,512,320);
  if(kind===1){
   imageFit(ctx,images[1],18,20,476,255,true,index===9?[.2,0,.65,1]:[0,0,1,1]);
   type(ctx,'SILHOUETTE / '+String(index+1).padStart(2,'0'),24,24,9);
   handwritten(ctx,notes[index],53,292,30,-.045);tape(ctx,344,8,111,.04);
   ctx.strokeStyle='#666b4b77';ctx.lineWidth=.7;ctx.beginPath();ctx.moveTo(321,268);ctx.quadraticCurveTo(385,244,452,259);ctx.stroke();
  }else if(kind===2){
   ctx.strokeStyle='#8b8e7733';ctx.lineWidth=.7;for(let y=57;y<306;y+=26){ctx.beginPath();ctx.moveTo(14,y);ctx.lineTo(498,y);ctx.stroke();}
   type(ctx,'ATELIER NOTE / '+String(index+1).padStart(2,'0'),30,35,10);
   handwritten(ctx,notes[index],31,101,29,-.085);
   handwritten(ctx,'What if we let',36,151,27,-.05);handwritten(ctx,'the fabric speak?',30,187,27,-.08);
   ctx.save();ctx.translate(331,146);ctx.rotate(.07);ctx.fillStyle='#faf3df';ctx.fillRect(-60,-106,175,226);imageFit(ctx,images[0],-53,-100,160,198,false);ctx.restore();
   tape(ctx,327,21,118,.13);handwritten(ctx,'jade studio',35,280,24,-.04);
   ctx.strokeStyle='#454936';ctx.beginPath();ctx.moveTo(36,198);ctx.lineTo(231,190);ctx.stroke();
  }else{
   ctx.save();ctx.translate(185,135);ctx.rotate(-.06);ctx.fillStyle='#c4bea6';ctx.fillRect(-143,-105,293,225);ctx.fillStyle='#f5efdb';ctx.fillRect(-148,-109,293,225);imageFit(ctx,images[1],-136,-97,269,180,true,[.15,0,.65,1]);ctx.restore();
   ctx.save();ctx.translate(382,159);ctx.rotate(.12);ctx.fillStyle='#faf2dd';ctx.fillRect(-83,-115,157,238);imageFit(ctx,images[0],-75,-108,140,204,false);ctx.restore();
   tape(ctx,53,8,131,-.07);tape(ctx,349,23,106,.11);
   ctx.save();ctx.translate(115,264);ctx.rotate(-.04);ctx.fillStyle='#d8d3b9';ctx.fillRect(-78,-26,300,57);handwritten(ctx,notes[index],-62,10,29,0);ctx.restore();
   type(ctx,'JADE / FOUND & KEPT',294,310,8);
  }
  grain(ctx,random);ctx.restore();
 }
 // The opening uses the same compositions without printed or handwritten text.
 if(text){
 ctx.save();ctx.translate(28,244);ctx.rotate(-.025);
 ctx.fillStyle='#efe4c9';ctx.fillRect(0,0,260,56);
 ctx.strokeStyle='#5e624c55';ctx.strokeRect(.5,.5,259,55);
 ctx.fillStyle='#303b2c';ctx.font='24px "Songti SC","Noto Serif CJK SC",SimSun,serif';
 ctx.fillText(CATEGORIES[index].label,12,28);
 ctx.font='10px "Special Elite",monospace';ctx.fillText(CATEGORIES[index].english.toUpperCase(),12,46);ctx.restore();
 }
 canvas.dataset.kind=kind===0?'film':kind===1?'sketch':kind===2?'handwritten-note':'paper-collage';return canvas;
}
export function paperTexture(images,index){
 const canvas=paperCanvas(images,index),texture=new THREE.CanvasTexture(canvas);texture.colorSpace=THREE.SRGBColorSpace;
 texture.userData.kind=canvas.dataset.kind;return texture;
}
