import {finishLanding} from './postcard.js?v=cover1';
import {CATEGORIES} from './categories.mjs?v=cover1';
import {journey,exploreJourney,restartJourney,backJourney,preparePortfolio} from './pages.js?v=cover1';
const intro=document.querySelector('#intro'),host=document.querySelector('#film-orbit'),site=document.querySelector('#site');
const status=document.querySelector('#intro-status'),pauseButton=document.querySelector('#pause-intro'),entry=document.querySelector('#enter-studio'),filmChoices=document.querySelector('#film-choices'),backButton=document.querySelector('#intro-back');
const reduce=matchMedia('(prefers-reduced-motion: reduce)');
let scene,preparing,sceneReady=false,run=0,raf=0,last=0,elapsed=0,paused=false,stage='ring',sceneState={spread:0};
CATEGORIES.forEach(c=>{const b=document.createElement('button');b.textContent=c.label+' ↗';b.dataset.index=c.index;b.setAttribute('aria-label','打开'+c.label+'作品集');b.addEventListener('click',e=>{e.stopPropagation();enter(c.index);});filmChoices.append(b);});
function cleanup(){cancelAnimationFrame(raf);last=0;}
function choices(open){filmChoices.classList.toggle('is-open',open);}
function controls(){const exploring=stage==='scatter',transitioning=exploring&&sceneReady&&sceneState.spread<1;intro.dataset.stage=stage;entry.hidden=stage!=='ring';backButton.hidden=!exploring||transitioning;filmChoices.hidden=!exploring||transitioning;pauseButton.hidden=!sceneReady||stage==='zoom'||stage==='gather'||transitioning;}
export function finishIntro(){run++;cleanup();intro.hidden=true;intro.dataset.state='entered';site.inert=false;document.body.classList.remove('playing');pauseButton.hidden=true;finishLanding();}
function enter(index){
 if(intro.hidden||stage!=='scatter'||(sceneReady&&sceneState.spread<.999)||!Number.isInteger(index)||index<0||index>=CATEGORIES.length)return;
 const artwork=sceneReady?scene.selectedArtwork(index):null,target=preparePortfolio(index,artwork);
 stage='zoom';intro.dataset.state='zoom';intro.dataset.selection='clicked';intro.dataset.selectedFrame=String(index);choices(false);controls();
 if(!sceneReady){finishIntro();return;}scene.startZoom(index,reduce.matches,target);sceneState=scene.render(elapsed);if(sceneState.zoomDone)finishIntro();
}
function scatter(){
 if(stage!=='ring')return;exploreJourney();stage='scatter';sceneState={spread:0};controls();status.textContent='';
 if(sceneReady){scene.scatter(reduce.matches);sceneState=scene.render(elapsed);intro.dataset.state='scatter';}else{intro.dataset.state='fallback';choices(true);status.textContent='选择一个方向，进入作品集';}
}
function gather(){
 if(stage!=='scatter')return;backJourney();choices(false);stage='gather';controls();status.textContent='RETURNING TO THE ATELIER';
 if(sceneReady){scene.gather(reduce.matches);sceneState=scene.render(elapsed);if(sceneState.gatherDone){stage='ring';controls();}}else{stage='ring';controls();}
}
function frame(time){
 if(intro.hidden)return;const delta=last?Math.min((time-last)/1000,.1):0;last=time;
 if(scene&&!document.hidden){elapsed+=delta;const focusPause=filmChoices.contains(document.activeElement)||filmChoices.classList.contains('is-open');sceneState=scene.render(elapsed,{paused:paused||focusPause,reduced:reduce.matches});
  if(stage==='gather'&&sceneState.gatherDone){stage='ring';controls();intro.dataset.state='orbit';status.textContent='PAPER / PENCIL / POSSIBILITIES';}
  if(stage==='scatter'&&sceneState.spread>=1){status.textContent='点击一张纸图，整张贴入作品集';controls();}
  if(stage==='zoom'&&sceneState.zoomDone){finishIntro();return;}
 }raf=requestAnimationFrame(frame);
}
export async function playIntro({resume=false,preserve=false}={}){
 finishIntro();const token=run;sceneReady=false;if(!resume&&!preserve)restartJourney();stage=resume?'scatter':'ring';elapsed=0;
 intro.hidden=false;intro.dataset.state='loading';delete intro.dataset.fixed;delete intro.dataset.selection;choices(false);controls();
 filmChoices.querySelectorAll('button').forEach((b,i)=>b.setAttribute('aria-current',String(resume&&i===journey.index)));
 site.inert=true;document.body.classList.add('playing');window.scrollTo({top:0,behavior:'instant'});if(!resume)paused=false;pauseButton.textContent=paused?'继续 ▷':'暂停 Ⅱ';intro.dataset.paused=String(paused);intro.style.removeProperty('--landing-cover');status.textContent='PREPARING THE ATELIER…';
 try{
  if(!preparing)preparing=import('./spatial-intro.js?v=cover1').then(m=>m.createSpatialIntro(host)).then(s=>(scene=s)).catch(error=>{preparing=null;throw error;});
  let timer;try{await Promise.race([preparing,new Promise((_,reject)=>{timer=setTimeout(()=>reject(new Error('Atelier loading timed out')),12000);})]);}finally{clearTimeout(timer);}
  if(token!==run)return;sceneReady=true;scene.reset({resume});scene.resize();sceneState=scene.render(0,{reduced:reduce.matches});
  if(stage==='scatter'&&!resume){scene.scatter(true);sceneState=scene.render(0);}intro.dataset.state=stage==='ring'?'orbit':'scatter';controls();cleanup();raf=requestAnimationFrame(frame);
 }catch(error){if(token!==run)return;intro.dataset.state='fallback';status.textContent='选择一个方向，进入作品集';pauseButton.hidden=true;if(stage==='scatter'){filmChoices.hidden=false;choices(true);}console.warn('Atelier renderer unavailable; category navigation remains usable.',error.message);}
}
export function returnToSpiral(){backJourney();playIntro({resume:true});}
pauseButton.addEventListener('click',e=>{e.stopPropagation();paused=!paused;pauseButton.textContent=paused?'继续 ▷':'暂停 Ⅱ';intro.dataset.paused=String(paused);});
filmChoices.addEventListener('keydown',e=>{if(e.key==='Escape'){choices(false);backButton.focus({preventScroll:true});}});
backButton.addEventListener('click',e=>{e.stopPropagation();gather();});
intro.addEventListener('click',e=>{if(stage==='ring'&&!e.target.closest('#pause-intro'))scatter();});
addEventListener('jade:film-selected',e=>enter(e.detail.index));
addEventListener('resize',()=>{scene?.resize();if(scene&&!intro.hidden)sceneState=scene.render(elapsed,{paused:true,reduced:reduce.matches});});
document.addEventListener('visibilitychange',()=>{last=0;});
reduce.addEventListener('change',()=>{last=0;if(!scene||intro.hidden)return;if(stage==='scatter')scene.scatter(true);if(stage==='gather')scene.gather(true);sceneState=scene.render(elapsed,{reduced:reduce.matches});});
addEventListener('pagehide',cleanup);addEventListener('pageshow',e=>{if(e.persisted&&!intro.hidden&&scene){cleanup();raf=requestAnimationFrame(frame);}});
export function startOpening(){playIntro();}
