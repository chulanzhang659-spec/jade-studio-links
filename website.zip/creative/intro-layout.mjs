export function filmPose(index,total,width,height){
 const progress=index/Math.max(1,total-1);
 const angle=(progress*1.45-.72)*Math.PI;
 return {x:Math.sin(angle)*width*.32+index*.01,y:Math.cos(angle)*height*.18-height*.08,rotation:(progress-.5)*48,rotationY:(.5-progress)*62,scale:.65+Math.sin(progress*Math.PI)*.3};
}
