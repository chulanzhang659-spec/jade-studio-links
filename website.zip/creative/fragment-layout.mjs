export const BREAK_DURATION=1.05;
const clamp=t=>Math.max(0,Math.min(1,t));
const ease=t=>{t=clamp(t);return t*t*(3-2*t);};
export const breakProgress=seconds=>clamp(seconds/BREAK_DURATION);
export function paperPieces(){
 let seed=1043;const rand=()=>{seed=(seed*1664525+1013904223)>>>0;return seed/4294967296;};
 const points=Array.from({length:7},(_,y)=>Array.from({length:8},(_,x)=>({x:(x+(x===0||x===7?0:(rand()-.5)*.58))/7,y:(y+(y===0||y===6?0:(rand()-.5)*.58))/6})));
 const pieces=[];for(let y=0;y<6;y++)for(let x=0;x<7;x++)pieces.push([points[y][x],points[y][x+1],points[y+1][x+1],points[y+1][x]]);
 const [a,b,c,d]=pieces.pop(),ab={x:(a.x+b.x)/2,y:(a.y+b.y)/2},dc={x:(d.x+c.x)/2,y:(d.y+c.y)/2};
 pieces.push([a,ab,dc,d],[ab,b,c,dc]);return pieces;
}
export function pieceUV(p,u,v){const [a,b,c,d]=p;return{x:(a.x*(1-u)+b.x*u)*(1-v)+(d.x*(1-u)+c.x*u)*v,y:(a.y*(1-u)+b.y*u)*(1-v)+(d.y*(1-u)+c.y*u)*v};}
export function fragmentScreen(source,target,center,index,p){
 if(p<=0)return{x:source.x,y:source.y};if(p>=1)return{x:target.x,y:target.y};
 const travel=ease((p-.17)/.83),burst=Math.sin(Math.PI*ease(p/.65))*(1-travel),angle=(index*2.39996),spin=burst*Math.sin(index*1.7)*.48;
 const dx=source.x-center.x,dy=source.y-center.y,scale=1+.55*burst;
 const x=center.x+(dx*Math.cos(spin)-dy*Math.sin(spin))*scale+Math.cos(angle)*.15*burst;
 const y=center.y+(dx*Math.sin(spin)+dy*Math.cos(spin))*scale+Math.sin(angle)*.13*burst;
 return{x:x+(target.x-x)*travel,y:y+(target.y-y)*travel};
}
