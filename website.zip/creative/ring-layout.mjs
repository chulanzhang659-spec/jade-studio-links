export const RING_COUNT=9;
export const RING_GREEN='#737541';
export function journeyStep(stage,action){
 if(stage==='ring'&&action==='explore')return 'scatter';
 if(stage==='scatter'&&action==='select-film')return 'atelier';
 return stage;
}
export function ringPoint(frame,u,v,phase=0){
 const angle=(frame+u)/RING_COUNT*Math.PI*2+phase;
 return [6.4*Math.cos(angle),(v-.5)*2.45,6.4*Math.sin(angle)];
}
export function entranceState({ready,visible,entered=false,reduced=false}){
 if(entered)return 'entered';
 if(!ready)return 'loading';
 return !visible||reduced?'still':'rotate';
}
