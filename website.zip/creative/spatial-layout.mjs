export function helixPose(index,count,phase=0){
 const t=index/Math.max(1,count-1),theta=t*Math.PI*4.8+phase;
 const radius=3.9+Math.sin(t*Math.PI)*.35;
 const x=Math.cos(theta)*radius,y=(t-.5)*10.8,z=Math.sin(theta)*radius;
 const tilt=-.52;
 return {x:x*Math.cos(tilt)-y*Math.sin(tilt),y:x*Math.sin(tilt)+y*Math.cos(tilt),z,angle:theta,size:.8+.28*(.5+.5*Math.sin(index*2.3))};
}
export function openingState({ready,visible,skipped=false,reduced=false}){
 if(skipped||reduced)return 'skip';
 if(!ready)return 'loading';
 return visible?'play':'waiting-visible';
}
