export const FLOW_COUNT=43,FLOW_CYCLE=90,FLOW_CAMERA=22.2;
const TAU=Math.PI*2,STEP=TAU/15;
const primary=Array.from({length:9},(_,i)=>i*5);
const slots=[...primary,...Array.from({length:FLOW_COUNT},(_,i)=>i).filter(i=>!primary.includes(i))];
export const flowSlot=i=>slots[i];
const smooth=t=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);};
export const transitionSpread=(from,to,t)=>from+(to-from)*smooth(t);
export const occluderOpacity=(initial,p)=>initial*(1-smooth(p/.18));
export const visibleInk=(alpha,opacity)=>alpha/255*opacity>=.45;
export const morphDepth=rank=>8+rank*.55;
export function morphTiming(toFlow,p){
 p=Math.max(0,Math.min(1,p));
 return toFlow?{primary:smooth(p/.82),extra:smooth((p-.82)/.18)}:{primary:smooth((p-.18)/.82),extra:1-smooth(p/.18)};
}
export function flowPose(slot,seconds){
 const q=((slot+seconds/FLOW_CYCLE*FLOW_COUNT)%FLOW_COUNT+FLOW_COUNT)%FLOW_COUNT;
 const shell=1+(slot%3)*.045,span=[.70,.28,.64,.36,.52,.25,.72,.38,.56][slot%9];
 return {angle:q*STEP+.25,height:(q-21)*.42,span,shell,shellMin:shell,shellMax:shell+.018,width:6.1*span*shell,opacity:smooth(q/1.4)*smooth((FLOW_COUNT-q)/1.4)};
}
export function flowPoint(u,v,slot,seconds,mobile=false){
 const p=flowPose(slot,seconds),angle=p.angle+(u-.5)*p.span;
 // Nonintersecting radial shells permit projected overlap. Same-shell angular
 // neighbours are three slots apart, wider apart than each full sheet's span.
 const r=p.shell+.012*Math.sin(Math.PI*u)*Math.sin(Math.PI*v)+.005*Math.abs(u-.5)*2;
 const x=Math.cos(angle)*6.1*r,z=Math.sin(angle)*8.8*r,y=p.height+(v-.5)*p.width/1.6+.055*(u-.5);
 const cx=Math.cos(.19),sx=Math.sin(.19),cz=Math.cos(-.35),sz=Math.sin(-.35),yy=y*cx-z*sx,zz=y*sx+z*cx;
 return {x:x*cz-yy*sz+.5,y:x*sz+yy*cz,z:zz,shade:.83+.14*Math.sin(angle)-.025*Math.abs(u-.5)*2};
}
export function resolveInstance(category,preferred,available=[]){
 if(Number.isInteger(preferred)&&preferred>=0&&preferred<FLOW_COUNT&&preferred%9===category)return preferred;
 return available.find(i=>i%9===category)??category;
}
