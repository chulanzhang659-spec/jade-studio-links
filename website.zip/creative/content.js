// Cover images and gallery items remain independent of the collage styling.
// Replace concept titles and assets with real studio work when ready.
export const collections = [
 {id:'01',title:'In Green',subtitle:'A silhouette study',image:'assets/fashion-cutout.webp',kind:'figure',status:'CONCEPT STUDY',body:'A study in a single colour: forest-green draping, an asymmetric line and the quiet contrast of an ivory glove.',gallery:[]},
 {id:'02',title:'Lines & Silhouettes',subtitle:'From the sketchbook',image:'assets/atelier-sketch.webp',kind:'sketch',status:'CONCEPT STUDY',body:'Loose lines, considered proportions. A small collection of imagined silhouettes, from the first pencil mark to the shape of a dress.',gallery:[]},
 {id:'03',title:'Texture Notes',subtitle:'A space for material studies',status:'COMING SOON',body:'Reserved for fabric, surface and construction studies. Studio work will appear here.',gallery:[]},
 {id:'04',title:'Collection 04',subtitle:'A collection in the making',status:'COMING SOON',body:'This space is reserved for a future studio collection.',gallery:[]},
 {id:'05',title:'Collection 05',subtitle:'A collection in the making',status:'COMING SOON',body:'This space is reserved for a future studio collection.',gallery:[]},
 {id:'06',title:'Collection 06',subtitle:'A collection in the making',status:'COMING SOON',body:'This space is reserved for a future studio collection.',gallery:[]},
 {id:'07',title:'Collection 07',subtitle:'A collection in the making',status:'COMING SOON',body:'This space is reserved for a future studio collection.',gallery:[]},
 {id:'08',title:'Collection 08',subtitle:'A collection in the making',status:'COMING SOON',body:'This space is reserved for a future studio collection.',gallery:[]}
];
export const notes={studio:{title:'A note from the atelier.',body:'JADE STUDIO is an independent fashion design studio. A place for silhouettes, textures and the small details that make something feel personal.',note:'This creative edition explores a visual direction. The illustrations are concept imagery, ready to be replaced with the studio’s own work.'},contact:{title:'Let’s make something.',body:'For collaborations, commissions and a conversation about what comes next.',note:'The studio’s contact details will be added here. This preview does not collect or send messages.'}};
