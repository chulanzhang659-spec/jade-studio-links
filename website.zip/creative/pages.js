import {CATEGORIES} from './categories.mjs?v=shred2';
import {createJourney,transition} from './journey-state.mjs?v=shred2';
import {preparePostcard} from './postcard.js?v=shred2';
export let journey=createJourney();
const $=s=>document.querySelector(s);
export function exploreJourney(){journey=transition(journey,'explore');}
export function restartJourney(){journey=transition(journey,'restart');}
export function backJourney(){journey=transition(journey,'back');return journey;}
function syncPages(){
 $('#portfolio').hidden=journey.stage!=='portfolio';$('#contact-page').hidden=journey.stage!=='contact';
 $('#site').dataset.page=journey.stage;$('#act-label').textContent=journey.stage==='contact'?'04 / CORRESPONDENCE':'03 / PORTFOLIO';
}
export function preparePortfolio(index,artwork=null){
 journey=transition(journey,'select',{index});
 const c=CATEGORIES[journey.index];syncPages();
 $('#portfolio-title').textContent=c.label;$('#portfolio-english').textContent=c.english;
 $('#portfolio-description').textContent=c.description;$('#portfolio-number').textContent=c.id+' / 09';
 $('#portfolio-caption').textContent='JADE / '+c.english.toUpperCase();
 const img=$('#portfolio-image'),source=$('#postcard-piece-'+c.index+' img');
 img.src=artwork?.src||source.src;img.alt=c.label+' — 纸张拼贴概念图';
 img.dataset.paper=artwork?.paper||'';
 if(!artwork)preparePostcard().then(()=>{if(journey.index===c.index&&!img.dataset.paper)img.src=source.isConnected?source.src:$('#postcard-piece-'+c.index+' img').src;}).catch(()=>{});
 $('#portfolio-gallery').replaceChildren();
 if(c.works.length){
  c.works.forEach(work=>{const figure=document.createElement('figure'),image=new Image(),caption=document.createElement('figcaption');image.src=work.src;image.alt=work.alt;caption.textContent=work.caption;figure.append(image,caption);$('#portfolio-gallery').append(figure);});
 }else{
  const sheet=document.createElement('div');sheet.className='work-reserved';
  const title=document.createElement('h3');title.textContent=c.label+' · 作品待补充';
  const description=document.createElement('p');description.textContent='这里将放入这一方向的项目、过程与成果。当前封面为视觉概念示意，不代表已完成的客户项目。';
  const note=document.createElement('span');note.className='folio-handwriting';note.textContent='A space for what comes next.';
  sheet.append(title,description,note);$('#portfolio-gallery').append(sheet);
 }
 window.scrollTo({top:0,behavior:'instant'});
 const cover=$('#portfolio-cover');cover.classList.add('pending-placement');cover.closest('.portfolio-spread').classList.remove('is-posted');cover.dataset.category=c.id;
 return cover;
}
export function showContact(){
 journey=transition(journey,'contact',{scroll:window.scrollY});syncPages();window.scrollTo({top:0,behavior:'instant'});$('#contact-title').focus({preventScroll:true});
}
export function returnToPortfolio(){
 journey=transition(journey,'back');syncPages();window.scrollTo({top:journey.scroll,behavior:'instant'});$('#to-contact').focus({preventScroll:true});
}
