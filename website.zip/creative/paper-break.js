import * as THREE from './assets/vendor/three.module.min.js';
import {paperPieces,pieceUV,fragmentScreen,breakProgress} from './fragment-layout.mjs?v=cover1';
import {flowPoint,flowPose,flowSlot} from './flow-layout.mjs?v=cover1';
import {smooth} from './paper-transitions.mjs?v=cover1';

// Temporary carriers only. Settled scene meshes and selection identities remain untouched.
export function createPaperBreak({scene,camera,meshes,openingTextures,textures,index,ringVertex,phase}){
 const group=new THREE.Group();scene.add(group);
 const sourceCamera=camera.clone();sourceCamera.updateMatrixWorld();
 const project=p=>new THREE.Vector3(p.x,p.y,p.z).project(sourceCamera);
 const ghosts=meshes.slice(0,9).filter((_,i)=>i!==index).map(m=>{
  const g=m.geometry.clone(),uv=g.attributes.uv,pos=g.attributes.position,screen=[];
  for(let n=0;n<pos.count;n++)screen.push(project(new THREE.Vector3().fromBufferAttribute(pos,n)));
  const mat=new THREE.MeshBasicMaterial({map:openingTextures[m.userData.category],side:THREE.DoubleSide,transparent:true,alphaTest:.01,depthTest:false,depthWrite:false,toneMapped:false});
  mat.onBeforeCompile=shader=>{shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',THREE.ShaderChunk.map_fragment.replace('texture2D( map, vMapUv )','texture2D(map,vec2(gl_FrontFacing ? vMapUv.x : 1.0-vMapUv.x,vMapUv.y))'));};
  mat.customProgramCacheKey=()=> 'paper-break-ghost';
  const ghost=new THREE.Mesh(g,mat);ghost.frustumCulled=false;ghost.renderOrder=1;group.add(ghost);return{mesh:ghost,screen};
 });
 const pieces=paperPieces().map((patch,i)=>{
  const geo=new THREE.PlaneGeometry(1,1,12,6),uv=geo.attributes.uv,sourceUV=[],screen=[];
  for(let n=0;n<uv.count;n++){const q=pieceUV(patch,uv.getX(n),uv.getY(n));sourceUV.push(q.x,q.y);screen.push(project(ringVertex(index,q.x,q.y)));}
  geo.setAttribute('sourceUv',new THREE.Float32BufferAttribute(sourceUV,2));
  const center=project(ringVertex(index,...Object.values(pieceUV(patch,.5,.5))));
  const mat=new THREE.MeshBasicMaterial({map:textures[i%9],side:THREE.DoubleSide,transparent:true,alphaTest:.01,depthTest:false,depthWrite:false,toneMapped:false});
  mat.userData.mix=0;
  mat.onBeforeCompile=shader=>{
   shader.uniforms.sourceMap={value:openingTextures[index]};shader.uniforms.paperMix={value:mat.userData.mix};mat.userData.shader=shader;
   shader.vertexShader='attribute vec2 sourceUv; varying vec2 patchUv;\n'+shader.vertexShader.replace('#include <uv_vertex>','#include <uv_vertex>\npatchUv=sourceUv;');
   shader.fragmentShader='uniform sampler2D sourceMap; uniform float paperMix; varying vec2 patchUv;\n'+shader.fragmentShader;
   shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',THREE.ShaderChunk.map_fragment.replace('texture2D( map, vMapUv )','mix(texture2D(sourceMap, vec2(gl_FrontFacing ? patchUv.x : 1.0-patchUv.x,patchUv.y)),texture2D(map,vec2(gl_FrontFacing ? vMapUv.x : 1.0-vMapUv.x,vMapUv.y)),paperMix)'));
  };
  mat.customProgramCacheKey=()=> 'irregular-paper-break';
  const m=new THREE.Mesh(geo,mat);m.frustumCulled=false;group.add(m);return{mesh:m,screen,center};
 });
 function place(pos,n,p,d){const h=d*Math.tan(camera.fov*Math.PI/360);pos.setXYZ(n,p.x*h*camera.aspect,p.y*h,camera.position.z-d);}
 function update(seconds){
  const p=breakProgress(seconds),landing=smooth((p-.85)/.15);group.visible=true;
  ghosts.forEach(({mesh,screen})=>{mesh.material.opacity=1-smooth(p/.23);mesh.visible=mesh.material.opacity>.001;screen.forEach((s,n)=>place(mesh.geometry.attributes.position,n,s,20));mesh.geometry.attributes.position.needsUpdate=true;});
  pieces.forEach(({mesh,screen,center},i)=>{
   const pos=mesh.geometry.attributes.position,uv=mesh.geometry.attributes.uv,slot=flowSlot(i),pose=flowPose(slot,phase);
   const z=flowPoint(.5,.5,slot,phase).z;mesh.renderOrder=10+Math.round((z+15)*100);
   mesh.material.userData.mix=smooth((p-.35)/.5);if(mesh.material.userData.shader)mesh.material.userData.shader.uniforms.paperMix.value=mesh.material.userData.mix;
   mesh.material.opacity=(1-landing)*(1-smooth((p-.65)/.35)+smooth((p-.65)/.35)*pose.opacity);
   for(let n=0;n<pos.count;n++){
    const target=projectTarget(flowPoint(uv.getX(n),uv.getY(n),slot,phase)),s=fragmentScreen(screen[n],target,center,i,p);
    place(pos,n,s,8+i*.06);
   }pos.needsUpdate=true;
  });return{progress:p,landing,done:p===1};
 }
 function projectTarget(p){return new THREE.Vector3(p.x,p.y,p.z).project(camera);}
 function dispose(){scene.remove(group);group.children.forEach(m=>{m.geometry.dispose();m.material.dispose();});}
 return{group,update,dispose};
}
