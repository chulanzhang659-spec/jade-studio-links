import {RING_COUNT} from './ring-layout.mjs?v=cover1';
import {COLUMN_COUNT} from './column-layout.mjs?v=cover1';
export const SPIRAL_COUNT=COLUMN_COUNT;
export const SPIRAL_CAMERA={desktop:20.3,mobile:24.5};
export function selectionMode(ready,reduced){return !ready?'direct':reduced?'snap':'animate';}
export function spiralPose(index,count,seconds,mobile){
 const t=index/(count-1),a=t*Math.PI*(count>RING_COUNT?5.2:3.25)+seconds*.19+.35;
 const radius=2.9+.22*Math.sin(t*Math.PI);
 const x=Math.cos(a)*radius,y=(t-.5)*5.8,z=Math.sin(a)*4.3;
 const tilt=-.10;
 return {x:(x*Math.cos(tilt)-y*Math.sin(tilt))*(mobile?.58:1),y:x*Math.sin(tilt)+y*Math.cos(tilt),z,
  yaw:Math.atan2(Math.cos(a)*4.3,Math.sin(a)*radius),
  angle:Math.sin(a)*.17+Math.sin(index*1.73)*.09,
  size:[1.14,.60,1.42,.78,1.02,.64,1.30,.84,1.08][index%9]};
}
export function choosePaperInstance(category,preferred,available){
 if(Number.isInteger(preferred)&&preferred>=0&&preferred<SPIRAL_COUNT&&preferred%RING_COUNT===category)return preferred;
 return available.find(i=>i%RING_COUNT===category)??category;
}
export function chooseFrame(index,available,random=Math.random){
 if(Number.isInteger(index)&&index>=0&&index<RING_COUNT)return index;
 const valid=available.filter(i=>Number.isInteger(i)&&i>=0&&i<RING_COUNT);
 const list=valid.length?valid:Array.from({length:RING_COUNT},(_,i)=>i);
 return list[Math.min(list.length-1,Math.floor(Math.max(0,random())*list.length))];
}
export function softPaperPoint(u,v,index,seconds,mobile=false){
 const pose=spiralPose(index,RING_COUNT,seconds,mobile),width=(mobile?3.05:4.3)*pose.size,height=width/1.6;
 const x=(u-.5)*width,y=(v-.5)*height,radius=mobile?2.7:3.35,angle=x/radius;
 const crease=.085*Math.abs((u-.55)+(v-.5)*.35);
 const curl=.12*Math.pow(Math.abs(v-.5)*2,3)*Math.sin(u*Math.PI+index);
 const breath=.025*Math.sin(seconds*.6+index)*Math.sin(u*Math.PI)*Math.sin(v*Math.PI);
 return {x:Math.sin(angle)*radius,y,z:.12-radius*(1-Math.cos(angle))+crease+curl+breath,shade:.86+.14*Math.cos(angle*1.3)-crease*.25};
}
