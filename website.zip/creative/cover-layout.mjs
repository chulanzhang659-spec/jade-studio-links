export const COVER_DURATION=1.25;
const clamp=x=>Math.max(0,Math.min(1,x));
const smooth=x=>{x=clamp(x);return x*x*(3-2*x);};
export function coverState(seconds){return{expand:smooth(seconds/.64),reveal:smooth((seconds-.76)/.49),covered:seconds>=.64,done:seconds>=COVER_DURATION};}
export function coverExtent(aspect){return{x:1.24*Math.max(1,1.6/aspect),y:1.24*Math.max(1,aspect/1.6)};}
export function coverPoint(source,target,u,v,aspect,seconds){const s=coverState(seconds);if(s.done)return{...target};if(s.expand===0)return{...source};const e=coverExtent(aspect),full={x:(u*2-1)*e.x,y:(v*2-1)*e.y};if(s.reveal>0)return{x:full.x+(target.x-full.x)*s.reveal,y:full.y+(target.y-full.y)*s.reveal};return{x:source.x+(full.x-source.x)*s.expand,y:source.y+(full.y-source.y)*s.expand};}
