import {MASTER,PAPERS,fitComposition,paperBounds} from './fixed-layout.mjs?v=shred2';
import {CATEGORIES} from './categories.mjs?v=shred2';
const NS='http://www.w3.org/2000/svg';
export function createFixedComposition(intro,{onSelect,onBack,onMenu}){
 const stage=document.createElement('div');stage.className='fixed-composition';stage.hidden=true;stage.setAttribute('aria-label','固定螺旋作品分类');
 const art=new Image();art.src=MASTER.src;art.alt='JADE STUDIO — Airy Spiral，固定纸张拼贴';art.draggable=false;
 const map=document.createElementNS(NS,'svg');map.setAttribute('viewBox',`0 0 ${MASTER.width} ${MASTER.height}`);map.classList.add('fixed-hit-map');
 const ready=art.decode();let selection=null,flight=null,animations=[],generation=0;
 const cancel=()=>{generation++;animations.forEach(a=>a.cancel());animations=[];flight?.remove();flight=null;};
 PAPERS.forEach(p=>{
  const region=document.createElementNS(NS,'polygon');region.setAttribute('points',p.points.map(pt=>pt.join(',')).join(' '));region.setAttribute('role','button');region.setAttribute('tabindex','0');region.setAttribute('aria-label',`打开${CATEGORIES[p.category].label}作品集，纸图 ${Number(p.id.slice(6))+1}`);region.dataset.paper=p.id;
  const activate=e=>{e.preventDefault();e.stopPropagation();selection=p;onSelect(p.category);};
  region.addEventListener('click',activate);region.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' ')activate(e);});map.append(region);
 });
 const back=document.createElement('button');back.className='fixed-back';back.textContent='返回开场';back.setAttribute('aria-label','返回开场');back.addEventListener('click',onBack);
 const next=document.createElement('button');next.className='fixed-next';next.textContent='选择创作分类';next.setAttribute('aria-label','选择创作分类');next.addEventListener('click',onMenu);
 stage.append(art,map,back,next);intro.append(stage);
 function layout(){const f=fitComposition(innerWidth,innerHeight);stage.style.cssText=`left:${f.left}px;top:${f.top}px;width:${f.width}px;height:${f.height}px`;return f;}
 function show(immediate=false){cancel();selection=null;layout();stage.hidden=false;stage.style.opacity='1';intro.dataset.fixed='true';if(!immediate)animations.push(stage.animate([{opacity:0},{opacity:1}],{duration:1450,easing:'cubic-bezier(.4,0,.2,1)',fill:'none'}));}
 function hide(){cancel();stage.hidden=true;delete intro.dataset.fixed;selection=null;}
 function select(index){
  if(!selection||selection.category!==index)selection=PAPERS.filter(p=>p.category===index).sort((a,b)=>{const aa=paperBounds(a),bb=paperBounds(b);return bb.width*bb.height-aa.width*aa.height;})[0];
  const bounds=paperBounds(selection),width=Math.ceil(Math.max(bounds.width,bounds.height*1.6)),height=width/1.6;
  const canvas=document.createElement('canvas');canvas.width=width;canvas.height=Math.ceil(height);const ctx=canvas.getContext('2d');
  const x=bounds.x-(width-bounds.width)/2,y=bounds.y-(canvas.height-bounds.height)/2;
  ctx.translate(-x,-y);ctx.beginPath();selection.points.forEach(([px,py],i)=>i?ctx.lineTo(px,py):ctx.moveTo(px,py));ctx.closePath();ctx.clip();ctx.drawImage(art,0,0);
  return {src:canvas.toDataURL('image/png'),x,y,width,height:canvas.height,paper:selection.id,category:index};
 }
 async function land(piece,target,immediate=false){
  cancel();const token=generation;const f=layout();
  const image=target.querySelector('img');await image.decode().catch(()=>{});if(token!==generation)return false;
  if(immediate)return true;
  flight=new Image();flight.src=piece.src;flight.alt='';flight.className='fixed-paper-flight';intro.append(flight);
  const left=f.left+piece.x*f.scale,top=f.top+piece.y*f.scale,width=piece.width*f.scale,height=piece.height*f.scale;
  flight.style.cssText=`left:${left}px;top:${top}px;width:${width}px;height:${height}px`;
  const r=image.getBoundingClientRect(),dx=r.left-left,dy=r.top-top,sx=r.width/width,sy=r.height/height;
  intro.style.setProperty('--landing-cover','0');intro.dataset.selectedPaper=piece.paper;
  const lift=flight.animate([
   {transform:'translate(0,0) scale(1,1)',filter:'drop-shadow(0 0 0 transparent)',offset:0},
   {transform:'translate(5px,-14px) rotate(-2deg) scale(1.025,1.025)',filter:'drop-shadow(7px 12px 8px #292c2455)',offset:.18},
   {transform:`translate(${dx}px,${dy-7}px) rotate(-1deg) scale(${sx},${sy})`,filter:'drop-shadow(3px 5px 3px #292c2444)',offset:.82},
   {transform:`translate(${dx}px,${dy}px) rotate(0deg) scale(${sx},${sy})`,filter:'drop-shadow(0 1px 1px #292c2422)',offset:1}
  ],{duration:1350,easing:'cubic-bezier(.22,.7,.3,1)',fill:'forwards'});
  const fade=stage.animate([{opacity:1},{opacity:0}],{duration:650,fill:'forwards'});animations.push(lift,fade);
  try{await lift.finished;}catch{return false;}
  if(token!==generation)return false;
  intro.dataset.landingMode='same-master-paper-sticker';intro.dataset.fixedLanding='complete';return true;
 }
 function resize(){layout();if(flight){animations.forEach(a=>{try{a.finish();}catch{}});}}
 addEventListener('resize',resize);
 return {ready,show,hide,select,land,layout,focusMenu:()=>next.focus({preventScroll:true})};
}
