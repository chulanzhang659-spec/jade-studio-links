import * as THREE from './assets/vendor/three.module.min.js';
import {RING_GREEN,ringPoint} from './ring-layout.mjs?v=cover1';
import {FLOW_COUNT,FLOW_CAMERA,flowPoint,flowPose,flowSlot,resolveInstance,transitionSpread,occluderOpacity,visibleInk,morphDepth,morphTiming} from './flow-layout.mjs?v=cover1';
import {preparePostcard,targetRect} from './postcard.js?v=cover1';
import {screenPoint} from './postcard-layout.mjs?v=cover1';
import {stickerPoint,smooth} from './paper-transitions.mjs?v=cover1';
import {createPaperBreak} from './paper-break.js?v=cover1';
import {createCameraCover} from './camera-cover.js?v=cover1';
export async function createSpatialIntro(host,onProgress=()=>{},{transition='cover'}={}){
 onProgress('PREPARING THE ATELIER');const canvases=await preparePostcard();
 const renderer=new THREE.WebGLRenderer({antialias:true,alpha:true,powerPreference:'low-power'});
 renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.setClearColor(RING_GREEN,0);renderer.setPixelRatio(Math.min(devicePixelRatio,1.5));
 const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(40,1,.1,240);
 const blendA=new THREE.WebGLRenderTarget(1,1),blendB=new THREE.WebGLRenderTarget(1,1),blendScene=new THREE.Scene(),blendCamera=new THREE.OrthographicCamera(-1,1,1,-1,0,1);
 const blendMaterial=new THREE.ShaderMaterial({transparent:true,depthTest:false,depthWrite:false,toneMapped:false,uniforms:{a:{value:blendA.texture},b:{value:blendB.texture},mixAmount:{value:0}},vertexShader:'varying vec2 uvOut; void main(){uvOut=uv;gl_Position=vec4(position.xy,0.,1.);}',fragmentShader:'uniform sampler2D a; uniform sampler2D b; uniform float mixAmount; varying vec2 uvOut; void main(){gl_FragColor=mix(texture2D(a,uvOut),texture2D(b,uvOut),mixAmount);\n#include <colorspace_fragment>\n}'});
 const blendQuad=new THREE.Mesh(new THREE.PlaneGeometry(2,2),blendMaterial);blendScene.add(blendQuad);
 const textureFor=c=>{const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());return t;};
 const textures=canvases.map(textureFor),openingTextures=canvases.map(c=>textureFor(c.openingCanvas)),sources=canvases.map(c=>c.toDataURL('image/png'));
 const alphaMaps=canvases.map(c=>({width:c.width,height:c.height,data:c.getContext('2d').getImageData(0,0,c.width,c.height).data}));
 const meshes=Array.from({length:FLOW_COUNT},(_,i)=>{
  const material=new THREE.MeshBasicMaterial({map:textures[i%9],side:THREE.DoubleSide,alphaTest:.45,depthTest:true,depthWrite:true,vertexColors:true,toneMapped:false});
  material.onBeforeCompile=shader=>{
   shader.uniforms.labelBlend={value:material.userData.blend||0};shader.uniforms.openingMap={value:openingTextures[i%9]};material.userData.shader=shader;
   shader.fragmentShader='uniform float labelBlend;\nuniform sampler2D openingMap;\n'+shader.fragmentShader;
   const uv='vec2(gl_FrontFacing ? vMapUv.x : 1.0-vMapUv.x,vMapUv.y)';
   shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',THREE.ShaderChunk.map_fragment.replace('texture2D( map, vMapUv )',`mix(texture2D(openingMap,${uv}),texture2D(map,${uv}),labelBlend)`));
  };
  material.customProgramCacheKey=()=> 'full-flow-paper';
  const geometry=new THREE.PlaneGeometry(1,1,32,12);geometry.setAttribute('color',new THREE.Float32BufferAttribute(new Float32Array(geometry.attributes.position.count*3).fill(1),3));
  const mesh=new THREE.Mesh(geometry,material);mesh.frustumCulled=false;mesh.userData={instance:i,category:i%9};scene.add(mesh);return mesh;
 });
 host.replaceChildren(renderer.domElement);renderer.domElement.setAttribute('aria-hidden','true');host.dataset.renderer='Three.js r'+THREE.REVISION+' / WebGL2';host.dataset.depth='true';host.dataset.materials='43 complete curved paper layers / 9 categories';
 const raycaster=new THREE.Raycaster(),pointer=new THREE.Vector2();
 let mode='ring',previous=0,flowSeconds=0,ringSeconds=0,morph=null,zoom=null,picked=null,hovered=false,spread=0,burst=null;
 const near=()=>camera.aspect<.8?27:16.4,far=()=>FLOW_CAMERA*Math.max(1,1.55/camera.aspect);
 function resize(){const w=host.clientWidth||innerWidth,h=host.clientHeight||innerHeight;camera.aspect=w/h;camera.updateProjectionMatrix();renderer.setSize(w,h,false);const d=renderer.getPixelRatio();blendA.setSize(w*d,h*d);blendB.setSize(w*d,h*d);}
 function ringVertex(i,u,v){const a=(i%9+u)/9*Math.PI*2+ringSeconds*.085,p=new THREE.Vector3(...ringPoint(i%9,u,v,ringSeconds*.085));p.y*=1+.40*(Math.sin(a)+1)/2;p.applyEuler(new THREE.Euler(.62,0,camera.aspect<.8?-.60:-.28));p.y+=(camera.aspect<.8?.6:.85)+Math.max(0,Math.sin(a))*(camera.aspect<.8?.45:.78);p.z+=Math.sin(a)*(Math.sin(a)>0?1.25:3);return p;}
 function setBlend(material,b){material.userData.blend=b;if(material.userData.shader)material.userData.shader.uniforms.labelBlend.value=b;}
 function paint(alreadyRendered=false){if(!alreadyRendered)renderer.render(scene,camera);host.dataset.planes=String(mode==='ring'?9:FLOW_COUNT);host.dataset.spread=spread.toFixed(4);host.dataset.phase=flowSeconds.toFixed(4);host.dataset.motion=mode;}
 function render(seconds,{paused=false,reduced=false}={}){
  const dt=Math.max(0,Math.min(.1,seconds-previous));previous=seconds;if(mode==='zoom')return renderZoom(seconds);if(mode==='break')return renderBreak(seconds);
  if(mode==='ring'&&!paused&&!reduced)ringSeconds+=dt;if(mode==='flow'&&!paused&&!reduced&&!hovered)flowSeconds+=dt;
  if(morph?.toFlow&&(seconds-morph.start)/2.2>=.82&&!paused&&!reduced)flowSeconds+=dt*smooth(((seconds-morph.start)/2.2-.82)/.18);
  let t=mode==='flow'?1:0,extra=mode==='flow'?1:0,finished=false;if(morph){const progress=(seconds-morph.start)/2.2,timing=morphTiming(morph.toFlow,progress);t=timing.primary;extra=timing.extra;finished=progress>=1;spread=transitionSpread(morph.fromSpread,morph.toFlow?1:0,t);}else spread=mode==='flow'?1:0;
  camera.position.set(0,0,near()+(far()-near())*spread);camera.lookAt(0,0,0);
  meshes.forEach((mesh,i)=>{
   const pose=flowPose(flowSlot(i),flowSeconds),pos=mesh.geometry.attributes.position,uv=mesh.geometry.attributes.uv,colors=mesh.geometry.attributes.color;
   mesh.material.opacity=morph&&!morph.toFlow&&i>=9?morph.opacities[i]*extra:(1-spread+spread*pose.opacity)*(i<9?1:extra);mesh.visible=mesh.material.opacity>0;
   mesh.material.transparent=mesh.material.opacity<.999;mesh.material.depthTest=true;mesh.material.depthWrite=true;mesh.renderOrder=0;setBlend(mesh.material,smooth((spread-.4)/.5));
   for(let n=0;n<pos.count;n++){
    const u=uv.getX(n),v=uv.getY(n),r=ringVertex(i,u,v),f=flowPoint(u,v,flowSlot(i),flowSeconds);let point=mode==='flow'?f:r;
    if(morph){
     if(i>=9)point=f;
     else if(t===0){const a=morph.vertices[i],k=n*3;point={x:a[k],y:a[k+1],z:a[k+2]};}
     else if(t===1)point=morph.toFlow?f:r;
     else {
      // Each complete sheet travels on its own depth plane: projected curves
      // retain their silhouette, without intersecting another moving sheet.
      const a=morph.screen[i],k=n*2,target=morph.toFlow?f:r,b=new THREE.Vector3(target.x,target.y,target.z).project(morph.targetCamera);
      const x=a[k]+(b.x-a[k])*t,y=a[k+1]+(b.y-a[k+1])*t,d=morphDepth(morph.ranks[i]),h=d*Math.tan(THREE.MathUtils.degToRad(camera.fov/2));
      point={x:x*h*camera.aspect,y:y*h,z:camera.position.z-d};
     }
    }
    pos.setXYZ(n,point.x,point.y,point.z);const shade=1+(f.shade-1)*spread;colors.setXYZ(n,shade,shade,shade);
   }
   pos.needsUpdate=true;colors.needsUpdate=true;mesh.geometry.computeBoundingSphere();
  });
  let composited=false;
  if(morph&&t>0&&t<1&&(t<.12||t>.88)){
   // Blend depth ordering at the handoff in two isolated render passes.
   // Physical and carrier geometry never coexist/intersect in one pass.
   renderer.setRenderTarget(blendA);renderer.render(scene,camera);
   const saved=meshes.slice(0,9).map(m=>m.geometry.attributes.position.array.slice());
   meshes.slice(0,9).forEach((m,i)=>{const pos=m.geometry.attributes.position,uv=m.geometry.attributes.uv;
    for(let n=0;n<pos.count;n++){const k=n*3;if(t<.12){const a=morph.vertices[i];pos.setXYZ(n,a[k],a[k+1],a[k+2]);}else{const p=morph.toFlow?flowPoint(uv.getX(n),uv.getY(n),flowSlot(i),flowSeconds):ringVertex(i,uv.getX(n),uv.getY(n));pos.setXYZ(n,p.x,p.y,p.z);}}pos.needsUpdate=true;
   });
   renderer.setRenderTarget(blendB);renderer.render(scene,camera);
   meshes.slice(0,9).forEach((m,i)=>{m.geometry.attributes.position.array.set(saved[i]);m.geometry.attributes.position.needsUpdate=true;});
   renderer.setRenderTarget(null);blendMaterial.uniforms.mixAmount.value=t<.12?1-smooth(t/.12):smooth((t-.88)/.12);renderer.render(blendScene,blendCamera);composited=true;
  }
  if(morph&&finished){mode=morph.toFlow?'flow':'ring';morph=null;}paint(composited);return {spread,zoomDone:false,gatherDone:mode==='ring',hovered};
 }
 function capture(){return meshes.map((m,i)=>{const source=i<9||spread>.5?m:meshes[i%9];return source.geometry.attributes.position.array.slice();});}
 function beginMorph(toFlow){
  const vertices=capture(),screen=vertices.map(a=>{const out=[];for(let k=0;k<a.length;k+=3){const p=new THREE.Vector3(a[k],a[k+1],a[k+2]).project(camera);out.push(p.x,p.y);}return out;});
  const order=meshes.slice(0,9).map((m,i)=>({i,z:m.geometry.boundingSphere.center.z})).sort((a,b)=>b.z-a.z),ranks=[];order.forEach((m,i)=>ranks[m.i]=i);
  const targetCamera=camera.clone();targetCamera.position.set(0,0,toFlow?far():near());targetCamera.lookAt(0,0,0);targetCamera.updateMatrixWorld();
  morph={start:previous,fromSpread:spread,toFlow,vertices,screen,ranks,targetCamera,opacities:meshes.map(m=>m.visible?m.material.opacity:0)};mode=toFlow?'unfold':'gather';
 }
 function clearBreak(){if(burst){burst.dispose();burst=null;}}
 function scatter(immediate=false){
  hovered=false;zoom=null;morph=null;clearBreak();
  if(immediate){mode='flow';spread=1;picked=null;return;}
  const index=Number.isInteger(picked)&&picked<9?picked:(visibleInstances().find(i=>i<9)??0);
  const createTransition=transition==='break'?createPaperBreak:createCameraCover;
  burst=createTransition({scene,camera,meshes,openingTextures,textures,index,ringVertex,phase:flowSeconds});burst.start=previous;mode='break';spread=0;host.dataset.breakSource=String(index);host.dataset.transition=transition==='break'?'medium-irregular-pieces':'photo-camera-cover';picked=null;
 }
 function renderBreak(seconds){
  // Reuse settled geometry without advancing its clock during the brief burst.
  const active=burst;active.group.visible=false;mode='flow';render(seconds,{paused:true});mode='break';
  const state=active.update(seconds-active.start);
  meshes.forEach(m=>{m.material.opacity*=state.landing;m.material.transparent=true;m.visible=m.material.opacity>0;m.material.depthWrite=state.landing>=1;});
  spread=state.done?1:0;host.dataset.breakProgress=state.progress.toFixed(4);
  if(state.done){clearBreak();mode='flow';return render(seconds,{paused:true});}
  paint();return{spread:0,zoomDone:false,gatherDone:false,hovered:false};
 }
 function gather(immediate=false){hovered=false;picked=null;zoom=null;if(immediate){mode='ring';spread=0;morph=null;}else beginMorph(false);}
 function visibleInstances(){return meshes.filter(m=>{const c=m.geometry.boundingSphere.center.clone().project(camera);return m.visible&&m.material.opacity>.8&&Math.abs(c.x)<.9&&Math.abs(c.y)<.9&&c.z<1;}).sort((a,b)=>b.geometry.boundingSphere.center.z-a.geometry.boundingSphere.center.z).map(m=>m.userData.instance);}
 function selectedArtwork(category){picked=resolveInstance(category,picked,visibleInstances());return {src:sources[category],paper:'sheet-'+picked,category};}
 function startZoom(category,immediate=false,target){
  if(zoom||!target)return;const index=resolveInstance(category,picked,visibleInstances()),mesh=meshes[index],pos=mesh.geometry.attributes.position;
  const points=Array.from({length:pos.count},(_,n)=>new THREE.Vector3().fromBufferAttribute(pos,n).project(camera));
  const a=points[0],b=points[32],c=points[396],back=(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x)>0;
  const screen=new Float32Array(pos.count*2),colors=new Float32Array(pos.count*3);
  for(let n=0;n<pos.count;n++){const from=back?Math.floor(n/33)*33+32-n%33:n,p=points[from];screen[n*2]=(p.x+1)/2;screen[n*2+1]=(1-p.y)/2;colors[n*3]=mesh.geometry.attributes.color.getX(from);}
  zoom={index,target,start:previous-(immediate?1.65:0),screen,colors,opacities:meshes.map(m=>m.visible?m.material.opacity:0)};mode='zoom';hovered=false;
  host.dataset.selectedInstance=String(index);host.dataset.selectedFrame=String(category);host.dataset.fullSheet='true';host.dataset.zoomContent='same-complete-sheet-on-portfolio';
 }
 function renderZoom(seconds){
  const p=Math.min(1,Math.max(0,(seconds-zoom.start)/1.65)),travel=Math.max(0,(p-.18)/.82),mesh=meshes[zoom.index];
  // Fade occluders at original depth before lifting, never pop through them.
  meshes.forEach((m,i)=>{if(i!==zoom.index){m.material.transparent=true;m.material.opacity=occluderOpacity(zoom.opacities[i],p);m.visible=m.material.opacity>0;}});
  if(p>=.18){
   const pos=mesh.geometry.attributes.position,uv=mesh.geometry.attributes.uv,r=targetRect(zoom.target),w=host.clientWidth,h=host.clientHeight;
   const distance=8,vh=2*distance*Math.tan(THREE.MathUtils.degToRad(camera.fov/2)),vw=vh*camera.aspect;
   for(let n=0;n<pos.count;n++){const u=uv.getX(n),v=uv.getY(n),s=stickerPoint({x:zoom.screen[n*2]*w,y:zoom.screen[n*2+1]*h},screenPoint(r,u,v),u,v,travel);pos.setXYZ(n,(s.x/w-.5)*vw,(.5-s.y/h)*vh,camera.position.z-distance);const shade=zoom.colors[n*3]+(1-zoom.colors[n*3])*smooth(travel);mesh.geometry.attributes.color.setXYZ(n,shade,shade,shade);}
   pos.needsUpdate=true;mesh.geometry.attributes.color.needsUpdate=true;mesh.geometry.computeBoundingSphere();mesh.material.depthTest=false;mesh.renderOrder=20;
  }
  mesh.visible=true;mesh.material.opacity=1;mesh.material.transparent=false;setBlend(mesh.material,1);host.parentElement.style.setProperty('--landing-cover',String(1-smooth((p-.18)/.55)));
  paint();host.dataset.zoomProgress=p.toFixed(4);host.dataset.texturePreserved=String(mesh.material.map===textures[mesh.userData.category]);return {spread:1,zoomDone:p===1,zoomProgress:p};
 }
 function pick(event){const r=renderer.domElement.getBoundingClientRect();pointer.set((event.clientX-r.left)/r.width*2-1,-(event.clientY-r.top)/r.height*2+1);raycaster.setFromCamera(pointer,camera);return raycaster.intersectObjects(meshes.filter(m=>m.visible&&m.material.opacity>=.45)).find(hit=>{
  const map=alphaMaps[hit.object.userData.category],back=hit.face.normal.dot(raycaster.ray.direction)>0,u=back?1-hit.uv.x:hit.uv.x;
  const x=Math.max(0,Math.min(map.width-1,Math.floor(u*map.width))),y=Math.max(0,Math.min(map.height-1,Math.floor((1-hit.uv.y)*map.height)));
  return visibleInk(map.data[(y*map.width+x)*4+3],hit.object.material.opacity);
 });}
 function click(event){if(mode!=='flow'&&mode!=='ring')return;const hit=pick(event);if(hit){picked=hit.object.userData.instance;if(mode==='flow')window.dispatchEvent(new CustomEvent('jade:film-selected',{detail:{index:hit.object.userData.category}}));}}
 function move(event){hovered=mode==='flow'&&event.pointerType!=='touch'&&!!pick(event);host.style.cursor=hovered?'pointer':'default';}
 function leave(){hovered=false;host.style.cursor='default';}
 host.addEventListener('click',click);host.addEventListener('pointermove',move);host.addEventListener('pointerleave',leave);
 function reset({resume=false}={}){clearBreak();mode=resume?'flow':'ring';spread=resume?1:0;previous=0;morph=null;zoom=null;picked=null;hovered=false;if(!resume){flowSeconds=0;ringSeconds=0;}delete host.dataset.selectedInstance;delete host.dataset.zoomProgress;delete host.dataset.breakProgress;host.parentElement.style.removeProperty('--landing-cover');}
 function dispose(){clearBreak();host.removeEventListener('click',click);host.removeEventListener('pointermove',move);host.removeEventListener('pointerleave',leave);meshes.forEach(m=>{m.geometry.dispose();m.material.dispose();});[...textures,...openingTextures].forEach(t=>t.dispose());blendA.dispose();blendB.dispose();blendQuad.geometry.dispose();blendMaterial.dispose();renderer.dispose();}
 resize();renderer.compile(scene,camera);render(0);return {render,resize,scatter,gather,selectedArtwork,startZoom,reset,dispose};
}
