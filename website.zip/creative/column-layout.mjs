// One broad, continuous paper helix; its support cylinder is never rendered.
// Disjoint angular/vertical cells remain disjoint under the common tilt and rotation.
export const COLUMN_COUNT=36;
export const COLUMN_CAMERA={desktop:23.5,mobile:25.5};
export const COLUMN_TILT=-.10;
const RADIUS=7.8,STEP=2*Math.PI/15,RISE=.335;
const SIZES=[1.14,.60,1.42,.78,1.02,.64,1.30,.84,1.08];
function tiltPoint(x,y,z,mobile){
 const scale=mobile?.44:1,c=Math.cos(COLUMN_TILT),s=Math.sin(COLUMN_TILT);
 return {x:(x*c-y*s)*scale,y:(x*s+y*c)*scale,z:z*scale};
}
export function columnCell(index){
 // Maximum span .39 leaves .0288 radians between adjacent helical cells.
 const span=.25+.14*(SIZES[index%9]-.60)/.82,width=RADIUS*span;
 return {angle:index*STEP+.35,y:(index-(COLUMN_COUNT-1)/2)*RISE,span,width,height:width/1.6};
}
export function columnPoint(u,v,index,seconds,mobile=false){
 const cell=columnCell(index),local=(u-.5)*cell.span,angle=cell.angle+seconds*.14+local;
 // Tangential sheets bow outward; their edges wrap gently back, with fine creases.
 const dome=Math.sin(u*Math.PI)*Math.sin(v*Math.PI);
 const crease=.012*Math.abs(u-.52),edge=.04*Math.pow(Math.abs(v-.5)*2,3);
 const breath=.010*Math.sin(seconds*.5+index)*dome;
 const radius=RADIUS+.10*dome+crease+edge+breath;
 return {...tiltPoint(Math.cos(angle)*radius,cell.y+(v-.5)*cell.height+.035*(u-.5),Math.sin(angle)*radius,mobile),shade:.80+.17*Math.sin(angle)-edge*.7-crease};
}
