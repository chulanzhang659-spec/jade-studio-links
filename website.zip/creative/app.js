import {playIntro,startOpening,returnToSpiral,finishIntro} from './opening.js?v=shred2';
import {preparePostcard,finishLanding} from './postcard.js?v=shred2';
import {showContact,returnToPortfolio,preparePortfolio} from './pages.js?v=shred2';
const $=s=>document.querySelector(s);
preparePostcard().catch(()=>{$('#home').dataset.artwork='fallback';});
$('#portfolio-back').addEventListener('click',returnToSpiral);
$('#portfolio-back-bottom').addEventListener('click',returnToSpiral);
$('#contact-back').addEventListener('click',returnToPortfolio);
$('#to-contact').addEventListener('click',showContact);
$('#replay').addEventListener('click',()=>playIntro());
$('#brand-home').addEventListener('click',()=>playIntro());
$('#postcard-pieces').addEventListener('click',e=>{
 const b=e.target.closest('[data-category]');if(!b)return;
 preparePortfolio(Number(b.dataset.category));finishIntro();finishLanding();
});
startOpening();
