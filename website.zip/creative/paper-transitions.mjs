export const UNROLL_SECONDS=1.85,PASTE_SECONDS=1.35;
export const smooth=t=>{t=Math.max(0,Math.min(1,t));return t*t*(3-2*t);};
const slots=[...Array.from({length:9},(_,i)=>i*4),...Array.from({length:36},(_,i)=>i).filter(i=>i%4!==0)];
export const helixSlot=index=>slots[index];
export function unrollPoint(a,b,t,route){
 if(t<=0)return {...a};if(t>=1)return {x:b.x,y:b.y,z:b.z};
 const wrap=a=>Math.atan2(Math.sin(a),Math.cos(a));
 let start=Math.atan2(a.z,a.x),end=Math.atan2(b.z,b.x);
 if(route){start=route.from+wrap(start-route.from);end=route.from+(route.sweep??wrap(route.to-route.from))+wrap(end-route.to);}
 const delta=route?end-start:wrap(end-start);
 const angle=start+delta*t,r=Math.hypot(a.x,a.z)*(1-t)+Math.hypot(b.x,b.z)*t;
 return {x:Math.cos(angle)*r,y:a.y+(b.y-a.y)*t,z:Math.sin(angle)*r};
}
// Coordinates remain in the screen plane: lift, carry sideways, then press an edge down.
// No camera-depth interpolation and no behind-the-page entrance.
export function stickerPoint(source,target,u,v,p){
 if(p<=0)return {...source};if(p>=1)return {...target};
 const travel=smooth((p-.14)/.70),lift=Math.sin(Math.PI*p),corner=u*v;
 const press=1-smooth((p-.66)/.34),curl=24*corner*lift*press;
 return {x:source.x+(target.x-source.x)*travel+7*lift*press,
  y:source.y+(target.y-source.y)*travel-15*lift*press-curl};
}
