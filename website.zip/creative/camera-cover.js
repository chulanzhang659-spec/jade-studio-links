import * as THREE from './assets/vendor/three.module.min.js';
import {coverState,coverPoint,COVER_DURATION} from './cover-layout.mjs?v=shred2';
import {flowPoint,flowPose,flowSlot,FLOW_COUNT,FLOW_CAMERA} from './flow-layout.mjs?v=shred2';
import {smooth} from './paper-transitions.mjs?v=shred2';

export function createCameraCover({scene,camera,meshes,openingTextures,textures,index,phase}){
 const group=new THREE.Group();scene.add(group);
 const sourceCamera=camera.clone();sourceCamera.updateMatrixWorld();
 const project=(p,c=sourceCamera)=>new THREE.Vector3(p.x,p.y,p.z).project(c);
 const targetCamera=camera.clone();targetCamera.position.set(0,0,FLOW_CAMERA*Math.max(1,1.55/camera.aspect));targetCamera.lookAt(0,0,0);targetCamera.updateMatrixWorld();
 const candidates=Array.from({length:FLOW_COUNT},(_,i)=>i).filter(i=>i%9===index);
 const targetIndex=candidates.sort((a,b)=>score(a)-score(b))[0];
 function score(i){const p=project(flowPoint(.5,.5,flowSlot(i),phase),targetCamera);return Math.hypot(p.x,p.y)+10*(1-flowPose(flowSlot(i),phase).opacity);}
 const ghosts=meshes.slice(0,9).filter((_,i)=>i!==index).map(m=>{
  const g=m.geometry.clone(),screen=Array.from({length:g.attributes.position.count},(_,n)=>project(new THREE.Vector3().fromBufferAttribute(g.attributes.position,n)));
  const mat=new THREE.MeshBasicMaterial({map:openingTextures[m.userData.category],side:THREE.DoubleSide,transparent:true,alphaTest:.01,depthTest:false,depthWrite:false,toneMapped:false});
  mat.onBeforeCompile=s=>{s.fragmentShader=s.fragmentShader.replace('#include <map_fragment>',THREE.ShaderChunk.map_fragment.replace('texture2D( map, vMapUv )','texture2D(map,vec2(gl_FrontFacing?vMapUv.x:1.0-vMapUv.x,vMapUv.y))'));};mat.customProgramCacheKey=()=> 'cover-ghost';
  const mesh=new THREE.Mesh(g,mat);mesh.frustumCulled=false;group.add(mesh);return{mesh,screen};
 });
 const geometry=meshes[index].geometry.clone(),pos=geometry.attributes.position,uv=geometry.attributes.uv;
 const raw=Array.from({length:pos.count},(_,n)=>project(new THREE.Vector3().fromBufferAttribute(pos,n)));
 const isBack=(a,b,c)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x)>0;
 const back=isBack(raw[0],raw[32],raw[396]);
 const screen=raw.map((_,n)=>raw[back?Math.floor(n/33)*33+32-n%33:n]);
 const targetBack=isBack(project(flowPoint(0,1,flowSlot(targetIndex),phase),targetCamera),project(flowPoint(1,1,flowSlot(targetIndex),phase),targetCamera),project(flowPoint(0,0,flowSlot(targetIndex),phase),targetCamera));
 const material=new THREE.MeshBasicMaterial({map:textures[index],side:THREE.DoubleSide,transparent:true,alphaTest:.01,depthTest:false,depthWrite:false,toneMapped:false});
 material.userData.cover=0;material.userData.labels=0;
 material.onBeforeCompile=s=>{
  s.uniforms.openingMap={value:openingTextures[index]};s.uniforms.coverFill={value:material.userData.cover};s.uniforms.labels={value:material.userData.labels};material.userData.shader=s;
  s.fragmentShader='uniform sampler2D openingMap;uniform float coverFill;uniform float labels;\n'+s.fragmentShader;
  s.fragmentShader=s.fragmentShader.replace('#include <map_fragment>',THREE.ShaderChunk.map_fragment.replace('texture2D( map, vMapUv )','mix(texture2D(openingMap,vMapUv),texture2D(map,vMapUv),labels)')+'\ndiffuseColor.rgb=mix(vec3(0.807,0.753,0.591),diffuseColor.rgb,diffuseColor.a); diffuseColor.a=mix(diffuseColor.a,1.0,coverFill);');
 };material.customProgramCacheKey=()=> 'complete-camera-cover';
 const sheet=new THREE.Mesh(geometry,material);sheet.frustumCulled=false;sheet.renderOrder=10000;group.add(sheet);
 function place(attribute,n,p,d){const h=d*Math.tan(camera.fov*Math.PI/360);attribute.setXYZ(n,p.x*h*camera.aspect,p.y*h,camera.position.z-d);}
 function update(seconds){
  const s=coverState(seconds);group.visible=true;
  ghosts.forEach(({mesh,screen})=>{mesh.material.opacity=1-smooth(seconds/.33);mesh.visible=mesh.material.opacity>0;screen.forEach((p,n)=>place(mesh.geometry.attributes.position,n,p,20));mesh.geometry.attributes.position.needsUpdate=true;});
  for(let n=0;n<pos.count;n++){const u=uv.getX(n),v=uv.getY(n),target=project(flowPoint(targetBack?1-u:u,v,flowSlot(targetIndex),phase),camera);place(pos,n,coverPoint(screen[n],target,u,v,camera.aspect,seconds),7);}
  pos.needsUpdate=true;material.userData.cover=s.expand*(1-s.reveal);material.userData.labels=s.reveal;
  if(material.userData.shader){material.userData.shader.uniforms.coverFill.value=material.userData.cover;material.userData.shader.uniforms.labels.value=s.reveal;}
  material.opacity=1-smooth((s.reveal-.94)/.06);
  return{progress:Math.min(1,Math.max(0,seconds/COVER_DURATION)),landing:s.covered?1:0,done:s.done};
 }
 function dispose(){scene.remove(group);group.children.forEach(m=>{m.geometry.dispose();m.material.dispose();});}
 return{group,update,dispose};
}
