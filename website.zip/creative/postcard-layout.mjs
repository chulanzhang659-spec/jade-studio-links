import {CATEGORIES} from './categories.mjs?v=cover1';
export const POSTCARD_PIECES=CATEGORIES.map(c=>({index:c.index,id:'postcard-piece-'+c.index,x:(c.index%3)*33,y:Math.floor(c.index/3)*33,w:30,angle:0,name:c.label,collection:c.id}));
export function screenPoint(rect,u,v){
 const x=(u-.5)*rect.width,y=(.5-v)*rect.height,c=Math.cos(rect.angle),s=Math.sin(rect.angle);
 return {x:rect.cx+x*c-y*s,y:rect.cy+x*s+y*c};
}
