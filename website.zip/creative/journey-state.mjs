export function createJourney(){return {stage:'ring',index:0,scroll:0,autoSelect:false};}
export function transition(state,action,payload={}){
 if(action==='explore'&&state.stage==='ring')return {...state,stage:'scatter'};
 if(action==='select'&&(state.stage==='scatter'||state.stage==='contact')&&Number.isInteger(payload.index)&&payload.index>=0&&payload.index<9)return {...state,stage:'portfolio',index:payload.index,scroll:0};
 if(action==='contact'&&state.stage==='portfolio')return {...state,stage:'contact',scroll:Math.max(0,payload.scroll||0)};
 if(action==='back'){
  if(state.stage==='contact')return {...state,stage:'portfolio'};
  if(state.stage==='portfolio')return {...state,stage:'scatter',autoSelect:false};
  if(state.stage==='scatter')return {...state,stage:'ring',autoSelect:false};
 }
 if(action==='restart')return createJourney();
 return state;
}
