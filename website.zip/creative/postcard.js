import {paperCanvas} from './paper-textures.js?v=shred2';
import {POSTCARD_PIECES} from './postcard-layout.mjs?v=shred2';
let ready;
export function preparePostcard(){
 if(ready)return ready;
 const board=document.querySelector('#postcard-pieces');
 POSTCARD_PIECES.forEach(p=>{
  const b=document.createElement('button');b.id=p.id;b.className='postcard-piece';b.dataset.category=String(p.index);b.dataset.piece=String(p.index);b.dataset.angle=String(p.angle);
  b.setAttribute('aria-label','查看'+p.name+'作品集');
  b.title=p.name;
  b.style.cssText=`--x:${p.x}%;--y:${p.y}%;--w:${p.w}%;--angle:${p.angle}deg;--row:${Math.floor(p.index/2)};--column:${p.index%2};`;
  const img=document.createElement('img');img.src=p.index%2?'assets/atelier-sketch.webp':'assets/fashion-cutout.webp';img.alt=p.name;
  const label=document.createElement('span');label.className='postcard-caption';label.textContent=p.name+' ↗';
  b.append(img,label);board.append(b);
 });
 ready=(async()=>{
  const images=await Promise.all(['assets/fashion-cutout.webp','assets/atelier-sketch.webp'].map(src=>new Promise((resolve,reject)=>{const i=new Image();i.onload=()=>resolve(i);i.onerror=reject;i.src=src;})));
  await Promise.allSettled([document.fonts.load('28px "La Belle Aurore"'),document.fonts.load('12px "Special Elite"')]);
  return Promise.all(POSTCARD_PIECES.map(async p=>{const canvas=paperCanvas(images,p.index),image=new Image();canvas.openingCanvas=paperCanvas(images,p.index,{text:false});image.src=canvas.toDataURL('image/png');image.alt=p.name;image.width=768;image.height=480;await image.decode();document.getElementById(p.id).querySelector('img').replaceWith(image);return canvas;}));
 })();
 return ready;
}
export function legacyLandingTarget(index){
 const element=document.getElementById('postcard-piece-'+index);if(!element)return null;
 window.scrollTo({top:0,behavior:'instant'});
 element.classList.add('pending-placement');
 document.querySelector('#home').dataset.selectedPiece=String(index);
 return element;
}
export function targetRect(element){
 const image=element.querySelector('canvas,img'),r=image.getBoundingClientRect();return {cx:r.left+r.width/2,cy:r.top+r.height/2,width:r.width,height:r.height,angle:0};
}
export function finishLanding(){
 const element=document.querySelector('.pending-placement');element?.classList.remove('pending-placement');element?.closest('.portfolio-spread')?.classList.add('is-posted');document.querySelector('#portfolio-title')?.focus({preventScroll:true});
}
