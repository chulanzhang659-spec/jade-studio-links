// Explicit opt-in regression; diagnostic copy never appears in the normal UI.
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
export async function checkHover(stage){
 const report=document.createElement('pre');
 report.style.cssText='position:fixed;bottom:8px;left:20px;z-index:100;background:#182318;color:#fff;padding:14px;font:13px monospace;pointer-events:none';
 document.body.append(report);
 const lines=['DIRECTION / ROLL CHECK'];
 const log=text=>{lines.push(text);report.textContent=lines.join('\n');};
 let buttons=0;
 const event=(type,x)=>{
  const rect=stage.getBoundingClientRect();
  stage.dispatchEvent(new PointerEvent(type,{bubbles:true,clientX:rect.left+rect.width*x,clientY:rect.top+rect.height*.35,buttons,button:0,pointerId:1,pointerType:'mouse',isPrimary:true}));
 };
 const move=async x=>{event('pointermove',x);await wait(55);};
 const dragStart=x=>{buttons=1;event('pointerdown',x);};
 const dragEnd=x=>{buttons=0;event('pointerup',x);};
 const index=()=>Number(stage.dataset.pageIndex);
 const width=()=>Number(stage.dataset.rollWidth);
 const forward=async()=>{await move(.8);for(const x of [.73,.66,.59,.52,.45,.35])await move(x);await wait(1400);};
 try{
  report.textContent=lines.join('\n');await wait(100);
  const emptyWidth=width();
  await forward();
  if(index()!==1||width()<=emptyWidth)throw Error('left hover or roll growth failed');
  log('PASS · LEFT hover advances and thickens roll');
  for(const x of [.42,.49,.56,.63,.70,.80])await move(x);
  await wait(1000);
  if(index()!==1||Number(stage.dataset.renderProgress)!==0)throw Error('right hover navigated');
  log('PASS · RIGHT hover stays on current page');
  dragStart(.25);for(const x of [.32,.39,.46,.53,.60,.70])await move(x);dragEnd(.70);
  await wait(1400);
  if(index()!==0||Math.abs(width()-emptyWidth)>.00001)throw Error('right drag or roll shrink failed');
  log('PASS · RIGHT drag returns and thins roll');
  dragStart(.2);for(const x of [.3,.4,.5,.6,.7])await move(x);dragEnd(.7);
  await wait(1000);
  if(index()!==0)throw Error('returned before first page');
  log('PASS · first-page return is bounded');
  await forward();
  dragStart(.25);await move(.35);await move(.45);dragEnd(.45);await wait(1200);
  if(index()!==1||Number(stage.dataset.renderProgress)!==0)throw Error('short return did not cancel');
  log('PASS · short drag releases to flat paper');
  for(let step=0;step<9;step++){
   stage.dispatchEvent(new WheelEvent('wheel',{deltaX:-stage.clientWidth*.05,deltaY:0,bubbles:true,cancelable:true}));await wait(55);
  }
  await wait(1400);
  if(index()!==2||width()<=emptyWidth)throw Error('second page or accumulated roll failed');
  log('PASS · successive pages accumulate in roll');
  await move(.8);await move(.7);await move(.6);await wait(1200);
  if(index()!==2||Number(stage.dataset.renderProgress)!==0)throw Error('idle paper not flat');
  log('PASS · stopped hover becomes flat');
  await move(.8);await move(.3);
  dragStart(.2);for(const x of [.3,.4,.5,.6,.7])await move(x);dragEnd(.7);
  await wait(1400);
  if(index()!==1)throw Error('right drag could not take over an automatic left turn');
  log('PASS · deliberate drag takes over hover auto-turn');
  log('8 / 8 PASSED');
 }catch(error){log(`FAIL · ${error.message}`);report.style.background='#7b1919';}
}
