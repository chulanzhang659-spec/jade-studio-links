export function filterWorks(works,type='',tag=''){
 return works.filter(work=>(!type||work.type===type)&&(!tag||work.tags?.includes(tag)));
}
export function createBusinessPanel(portfolio){
 const panel=document.createElement('section');panel.className='business-panel';panel.lang='zh-CN';
 const results=document.createElement('div');results.className='business-results';results.setAttribute('aria-live','polite');
 let type='',tag='';
 function render(){
  results.replaceChildren();
  const works=filterWorks(portfolio.gallery,type,tag);
  if(!works.length){const p=document.createElement('p');p.className='business-empty';p.textContent=portfolio.gallery.length?'该筛选组合暂无已公开作品。':'作品正在整理，案例尚未公开。';results.append(p);return;}
  for(const work of works){const figure=document.createElement('figure'),img=document.createElement('img'),caption=document.createElement('figcaption');img.src=work.src;img.alt=work.alt||portfolio.subtitle;img.loading='lazy';caption.textContent=work.caption||'';figure.append(img,caption);results.append(figure);}
 }
 function group(title,values,key){
  const field=document.createElement('fieldset'),legend=document.createElement('legend');legend.textContent=title;field.append(legend);
  for(const value of ['',...values]){
   const button=document.createElement('button');button.type='button';button.textContent=value||'全部';button.setAttribute('aria-pressed',String(!value));
   button.addEventListener('click',()=>{if(key==='type')type=value;else tag=value;field.querySelectorAll('button').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));render();});field.append(button);
  }
  panel.append(field);
 }
 group('作品分类',portfolio.types,'type');group('细分方向',portfolio.tags,'tag');panel.append(results);render();return panel;
}
