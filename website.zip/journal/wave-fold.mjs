const smoothstep=(edge0,edge1,value)=>{
 const t=clamp01((value-edge0)/(edge1-edge0));
 return t*t*(3-2*t);
};

export const clamp01=value=>Math.min(1,Math.max(0,Number.isFinite(value)?value:0));

export function waveState(uvX,progress){
 const x=clamp01(uvX);
 const p=clamp01(progress);
 const crestX=1.16-p*1.32;
 const width=0.19;
 const distance=(x-crestX)/width;
 const bend=Math.exp(-distance*distance);
 const swept=smoothstep(crestX-width,crestX+width,x);
 const mappedX=x*(1-swept)+(0.028+x*0.082)*swept;
 return {crestX,bend,swept,mappedX};
}

export function stepWaveMotion(state,input={},deltaSeconds=1/60){
 const delta=Math.min(0.05,Math.max(1/240,deltaSeconds));
 const current=clamp01(state?.progress??0);
 const previousVelocity=Number.isFinite(state?.velocity)?state.velocity:0;

 if(input.dragging){
  const progress=clamp01(input.targetProgress);
  const velocity=Math.max(-2.4,Math.min(2.4,(progress-current)/delta));
  return {progress,velocity};
 }

 const autoVelocity=Number.isFinite(input.autoVelocity)?input.autoVelocity:0;
 let velocity=(previousVelocity+autoVelocity*delta)*Math.exp(-5.2*delta);
 let progress=clamp01(current+velocity*delta);
 if((progress===0&&velocity<0)||(progress===1&&velocity>0))velocity=0;
 return {progress,velocity};
}
