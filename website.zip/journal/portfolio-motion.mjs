import {clamp,smoothValue} from './elastic-field.mjs';
// Velocity, never absolute cursor position: idle input returns the lockup home.
export function stepPortfolioMotion(state,velocity,dt,reduced){
 if(reduced)return {shiftX:0,direction:state.direction};
 return {shiftX:smoothValue(state.shiftX,clamp(velocity*1.5,-52,52),dt,180),direction:Math.abs(velocity)>2?Math.sign(velocity):state.direction};
}
