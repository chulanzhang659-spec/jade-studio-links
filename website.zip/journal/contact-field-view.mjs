import {contactInfluence,dampContact} from './contact-field.mjs';

const REST={x:0,y:0,scale:0};
const nearRest=value=>Math.abs(value.x)<.01&&Math.abs(value.y)<.01&&Math.abs(value.scale)<.001;

export function mountContactField(root){
 const reduced=window.matchMedia('(prefers-reduced-motion: reduce)').matches;
 const items=[...root.querySelectorAll('[data-contact-glyph]')].map(element=>({element,current:{...REST},target:{...REST}}));
 let frame=0,last=performance.now(),disposed=false;
 function draw(now){
  if(disposed)return;
  const dt=Math.min((now-last)/1000,.05);last=now;
  let moving=false;
  for(const item of items){
   item.current=dampContact(item.current,item.target,dt);
   if(!nearRest(item.current)||!nearRest(item.target))moving=true;
   if(nearRest(item.current)&&nearRest(item.target))item.element.style.removeProperty('transform');
   else item.element.style.transform=`translate3d(${item.current.x.toFixed(2)}px,${item.current.y.toFixed(2)}px,0) scale(${(1+item.current.scale).toFixed(4)})`;
  }
  frame=moving?requestAnimationFrame(draw):0;
 }
 function schedule(){if(!frame){last=performance.now();frame=requestAnimationFrame(draw);}}
 function onMove(event){
  if(reduced)return;
  const pointer={x:event.clientX,y:event.clientY};
  for(const item of items){
   const box=item.element.getBoundingClientRect();
   item.target=contactInfluence(pointer,{x:box.left+box.width/2,y:box.top+box.height/2},Math.max(150,innerWidth*.15));
  }
  schedule();
 }
 function onLeave(){for(const item of items)item.target={...REST};schedule();}
 root.addEventListener('pointermove',onMove,{passive:true});
 root.addEventListener('pointerleave',onLeave,{passive:true});
 return {dispose(){
  disposed=true;if(frame)cancelAnimationFrame(frame);
  root.removeEventListener('pointermove',onMove);root.removeEventListener('pointerleave',onLeave);
  for(const item of items)item.element.style.removeProperty('transform');
 }};
}
