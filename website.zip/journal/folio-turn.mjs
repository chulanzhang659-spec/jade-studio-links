export const TURN_MS=920;

function inertClone(page,className){
 const clone=page.cloneNode(true);
 clone.querySelectorAll('[id]').forEach(node=>node.removeAttribute('id'));
 clone.querySelectorAll('a,button,input,select,textarea').forEach(node=>node.tabIndex=-1);
 clone.classList.add('folio-turning-page',className,'is-turning');
 clone.inert=true;
 clone.setAttribute('aria-hidden','true');
 clone.style.transformOrigin='left center';
 return clone;
}

function textMotion(clone,direction){
 const nodes=clone.querySelectorAll('.turn-distort,[data-turn-text]');
 const keyframes=direction>0
  ?[{transform:'translateX(0) skewX(0) scaleX(1)',filter:'blur(0)',letterSpacing:'inherit'},{transform:'translateX(-9vw) skewX(-13deg) scaleX(.72)',filter:'blur(.4px)',letterSpacing:'-.035em'}]
  :[{transform:'translateX(-7vw) skewX(-11deg) scaleX(.76)',filter:'blur(.4px)',letterSpacing:'-.03em'},{transform:'translateX(0) skewX(0) scaleX(1)',filter:'blur(0)',letterSpacing:'inherit'}];
 return [...nodes].map((node,index)=>node.animate(keyframes,{duration:TURN_MS*.78,delay:index%5*12,easing:'cubic-bezier(.5,0,.22,1)',fill:'both'}));
}

export async function turnFolio({shell,page,direction,renderTarget,onCommit=()=>{},reducedMotion=false}){
 if(shell.dataset.turning==='true'||!direction)return false;
 shell.dataset.turning='true';
 shell.classList.add('is-turning');
 if(reducedMotion){
  renderTarget();onCommit();
  delete shell.dataset.turning;shell.classList.remove('is-turning');
  return true;
 }
 const oldHeight=page.getBoundingClientRect().height;
 shell.style.minHeight=`${oldHeight}px`;
 let active;
 const obsolete=[];
 if(direction>0){
  active=inertClone(page,'is-forward');
  shell.append(active);
  renderTarget();
 }else{
  const under=inertClone(page,'is-under');
  under.style.zIndex='18';
  shell.append(under);obsolete.push(under);
  renderTarget();
  active=inertClone(page,'is-backward');
  shell.append(active);
 }
 shell.style.minHeight=`${Math.max(oldHeight,page.getBoundingClientRect().height)}px`;
 const textAnimations=textMotion(active,direction);
 const paper=active.animate(
  direction>0
   ?[
     {transform:'rotateY(0deg) translateZ(0)',filter:'brightness(1)',borderRadius:'0'},
     {offset:.48,transform:'rotateY(-92deg) translateZ(12px) skewY(-.8deg)',filter:'brightness(.76)',borderRadius:'0 7% 7% 0'},
     {transform:'rotateY(-178deg) translateZ(0)',filter:'brightness(.9)',borderRadius:'0'}
    ]
   :[
     {transform:'rotateY(-178deg) translateZ(0)',filter:'brightness(.9)',borderRadius:'0'},
     {offset:.52,transform:'rotateY(-88deg) translateZ(12px) skewY(.8deg)',filter:'brightness(.76)',borderRadius:'0 7% 7% 0'},
     {transform:'rotateY(0deg) translateZ(0)',filter:'brightness(1)',borderRadius:'0'}
    ],
  {duration:TURN_MS,easing:'cubic-bezier(.62,.01,.22,1)',fill:'forwards'}
 );
 try{await paper.finished;await Promise.allSettled(textAnimations.map(animation=>animation.finished));}
 finally{
  paper.cancel();textAnimations.forEach(animation=>animation.cancel());
  active.remove();obsolete.forEach(node=>node.remove());
  shell.style.minHeight='';delete shell.dataset.turning;shell.classList.remove('is-turning');
 }
 onCommit();
 return true;
}
