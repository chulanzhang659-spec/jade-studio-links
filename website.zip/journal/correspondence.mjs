export function contactURL(id){return /^portfolio-0[1-6]$/.test(id)?`contact.html?project=${id}`:'contact.html';}
export function coverForProject(portfolio,slot){
 const first=portfolio?.gallery?.[0];
 return {src:first?.src||slot?.src||slot?.preview||'',alt:first?.alt||`${portfolio?.subtitle||'JADE STUDIO'} · 视觉示意图`,position:`${(slot?.crop?.[0]??.5)*100}% ${(slot?.crop?.[1]??.5)*100}%`,caption:first?(first.caption||portfolio.subtitle):'视觉示意图 / PREVIEW ART'};
}
export function paperJourney(from,to){
 const x=to.left-from.left,y=to.top-from.top,sx=to.width/from.width,sy=to.height/from.height;
 const lifted=`translate(${x}px,${y-65}px) scale(${sx},${sy}) rotate(-8deg)`;
 const landed=`translate(${x}px,${y}px) scale(${sx},${sy}) rotate(-8deg)`;
 return {lift:[{transform:'translate(0px,0px) scale(1,1) rotate(0deg)'},{transform:lifted}],insert:[{transform:lifted},{transform:landed}],duration:1350};
}
