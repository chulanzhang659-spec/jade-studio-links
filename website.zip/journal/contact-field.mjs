const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));

export function contactInfluence(pointer,item,radius=180){
 const dx=pointer.x-item.x,dy=pointer.y-item.y,distance=Math.hypot(dx,dy);
 const strength=clamp(1-distance/Math.max(1,radius),0,1);
 return {
  x:dx*.16*strength,
  y:dy*.16*strength,
  scale:.22*strength,
  strength
 };
}

export function dampContact(current,target,dt,tau=.095){
 const factor=1-Math.exp(-clamp(dt,0,.05)/tau);
 return {
  x:current.x+(target.x-current.x)*factor,
  y:current.y+(target.y-current.y)*factor,
  scale:current.scale+(target.scale-current.scale)*factor
 };
}
