import {manifestoSVG} from './journal-typography.mjs?v=jade-type-2';
import {playCompression} from './journal-transition.js?v=jade-type-2';

const $=selector=>document.querySelector(selector);
const content=window.JADE_CONTENT, intro=$('#intro'), main=$('#journal'), enter=$('#enter-studio');
const reduce=matchMedia('(prefers-reduced-motion: reduce)'), dialog=$('#story-dialog');
let ring,transition,opener,paused=false,stage='intro';
if('scrollRestoration' in history)history.scrollRestoration='manual';
const escapeHTML=value=>String(value).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

function renderManifesto(){const rect=$('#manifesto').getBoundingClientRect();$('#manifesto-type').innerHTML=manifestoSVG(rect.width||innerWidth,rect.height||innerHeight);}
function showJournal(){
 transition=null;stage='journal';document.body.dataset.stage=stage;
 intro.hidden=true;intro.inert=true;main.hidden=false;main.inert=false;ring?.pause();
 window.scrollTo({top:0,behavior:'instant'});renderManifesto();$('#manifesto').focus({preventScroll:true});
}
function selectImage(selection){
 if(stage!=='intro')return;
 stage='transition';document.body.dataset.stage=stage;intro.inert=true;ring?.pause();
 intro.dataset.selected=String(selection.index??'fallback');
 transition=playCompression({...selection,reducedMotion:reduce.matches,onComplete:showJournal});
}
function enterStudio(){
 if(stage!=='intro')return;
 if(ring?.selectFront())return;
 const image=$('.ring-fallback img');selectImage({image:image?.complete&&image.naturalWidth?image:null});
}
function returnToIntro(){
 transition?.cancel();transition=null;dialog.close();document.body.classList.remove('modal-open');
 stage='intro';document.body.dataset.stage=stage;main.hidden=true;main.inert=true;intro.hidden=false;intro.inert=false;
 window.scrollTo({top:0,behavior:'instant'});paused=false;$('#pause-intro').textContent='PAUSE Ⅱ';$('#pause-intro').setAttribute('aria-pressed','false');
 ring?.reset();if(reduce.matches)ring?.pause();enter.focus({preventScroll:true});
}
enter.addEventListener('click',enterStudio);
// The transparent canvas sits above the lettering for the original occlusion.
// A click through its empty centre still activates the visible entrance button.
intro.addEventListener('click',event=>{
 if(stage!=='intro'||event.target.tagName!=='CANVAS')return;
 const r=enter.getBoundingClientRect();
 if(event.clientX>=r.left&&event.clientX<=r.right&&event.clientY>=r.top&&event.clientY<=r.bottom)enterStudio();
});
document.querySelectorAll('[data-return]').forEach(button=>button.addEventListener('click',returnToIntro));
$('#skip-to-work').addEventListener('click',event=>{event.preventDefault();transition?.cancel();showJournal();$('#portfolio-index').scrollIntoView({behavior:'instant'});$('#portfolio-grid button')?.focus({preventScroll:true});});
$('#pause-intro').addEventListener('click',()=>{paused=!paused;if(paused)ring?.pause();else ring?.resume();$('#pause-intro').textContent=paused?'PLAY ▷':'PAUSE Ⅱ';$('#pause-intro').setAttribute('aria-pressed',String(paused));});
reduce.addEventListener('change',()=>{if(reduce.matches){ring?.pause();if(stage==='transition'){transition?.cancel();showJournal();}}else if(stage==='intro'&&!paused)ring?.resume();});
window.addEventListener('resize',renderManifesto);

// The Journal's original eight-spine archive and its editable content are retained.
const portfolioGrid=$('#portfolio-grid');
content.portfolios.forEach((portfolio,index)=>{
 const number=String(index+1).padStart(2,'0'),asset=portfolio.image&&content.images[portfolio.image];
 content.stories[portfolio.id]={eyebrow:`STUDIO ARCHIVE / ${number} OF 08`,title:portfolio.title,body:portfolio.body,note:portfolio.status==='COMING SOON'?'作品集待更新 / Collection coming soon.':'Illustrative concept — imagery and copy will be replaced with studio work.',portfolio};
 const button=document.createElement('button');button.className='portfolio-entry';button.dataset.open=portfolio.id;button.dataset.preview=String(index===0);button.setAttribute('aria-label',`Open ${portfolio.title}`);
 const spineTitle=asset?portfolio.subtitle:`Collection ${number}`;
 button.innerHTML=`<span class="portfolio-spine"><span class="spine-number">${number}</span><span class="spine-title">${escapeHTML(spineTitle)}</span><span class="spine-arrow">↗</span></span><span class="portfolio-preview"><span class="portfolio-topline"><span>${escapeHTML(portfolio.title)} / JADE STUDIO</span><span>${escapeHTML(portfolio.status)}</span></span><span class="portfolio-cover ${asset?'has-art':'reserved-cover'}">${asset?`<img src="${escapeHTML(asset.src)}" style="object-position:${escapeHTML(asset.position)}" alt="${escapeHTML(portfolio.subtitle)} — concept illustration" loading="lazy">`:`<span class="reserved-number">${number}</span><span class="reserved-label">THIS PAGE IS RESERVED<br>FOR WHAT COMES NEXT.</span>`}</span><span class="portfolio-caption"><span class="portfolio-title">${escapeHTML(spineTitle)}<span>↗</span></span><span class="portfolio-subtitle">${asset?'A study in silhouette, texture & feeling.':'A collection in the making. Work coming soon.'}</span><span class="portfolio-open-label">OPEN COLLECTION</span></span></span>`;
 portfolioGrid.append(button);
 const preview=()=>portfolioGrid.querySelectorAll('.portfolio-entry').forEach(entry=>{entry.dataset.preview=String(entry===button);});
 button.addEventListener('pointerenter',event=>{if(event.pointerType==='mouse')preview();});button.addEventListener('focus',preview);
});
function openStory(key,trigger){
 const story=content.stories[key];if(!story||stage!=='journal')return;opener=trigger;
 const title=escapeHTML(story.title).replace(/&lt;br&gt;/g,'<br>');
 $('#story-content').innerHTML=`<p class="story-eyebrow">${escapeHTML(story.eyebrow)}</p><h2 class="story-heading" id="story-title">${title}</h2><p class="story-body">${escapeHTML(story.body)}</p><p class="story-note">${escapeHTML(story.note)}</p>`;
 if(story.portfolio){
  const portfolio=story.portfolio,cover=portfolio.image&&content.images[portfolio.image];
  const gallery=portfolio.gallery.length?portfolio.gallery:(cover?[{src:cover.src,alt:portfolio.subtitle,caption:'CONCEPT IMAGE / TO BE REPLACED'}]:[]),section=document.createElement('div');section.className='portfolio-gallery';
  section.innerHTML=gallery.length?gallery.map(item=>`<figure><img src="${escapeHTML(item.src)}" alt="${escapeHTML(item.alt||portfolio.title)}"><figcaption>${escapeHTML(item.caption||'')}</figcaption></figure>`).join(''):'<div class="gallery-reserved"><span>WORK COMING SOON</span><p>作品将在此处展示。</p></div>';
  $('#story-content').append(section);
 }
 dialog.showModal();dialog.scrollTop=0;document.body.classList.add('modal-open');$('#close-dialog').focus();
}
function closeStory(){dialog.close();document.body.classList.remove('modal-open');opener?.focus({preventScroll:true});}
document.querySelectorAll('[data-open]').forEach(button=>button.addEventListener('click',()=>openStory(button.dataset.open,button)));
$('#close-dialog').addEventListener('click',closeStory);$('#back-journal').addEventListener('click',closeStory);
dialog.addEventListener('cancel',event=>{event.preventDefault();closeStory();});
dialog.addEventListener('click',event=>{if(event.target!==dialog)return;const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)closeStory();});

function showFallback(){
 $('#film-orbit').innerHTML='<div class="ring-fallback"><img src="assets/fashion-cutout.webp" alt=""><img src="assets/atelier-sketch.webp" alt=""></div>';
 $('#intro-status').textContent='ENTER TO EXPLORE THE ATELIER';
}
try{
 const {createJournalRing}=await import('./journal-ring.js?v=jade-type-2');
 ring=await createJournalRing($('#film-orbit'),{onSelect:selectImage,reducedMotion:reduce.matches});
 if(stage!=='intro')ring.pause();
 $('#intro-status').textContent='SELECT A FRAME / STEP INSIDE THE ATELIER';$('#pause-intro').hidden=reduce.matches;
}catch(error){console.warn('Using still-image entrance:',error);showFallback();}
window.addEventListener('pagehide',()=>{transition?.cancel();ring?.pause();});
window.addEventListener('pageshow',()=>{if(stage==='transition')showJournal();else if(stage==='intro'&&!paused&&!reduce.matches)ring?.resume();});
