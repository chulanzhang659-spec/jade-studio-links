export function createRiverEnding(root){
 const brand=root.querySelector('.meeting-brand');
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const letters=[...'JADE STUDIO'];
 brand.setAttribute('aria-label','JADE STUDIO');
 brand.replaceChildren(...letters.map((letter,index)=>{
  const span=document.createElement('span');span.className='print-letter'+(index===0?' aligned-j':'');
  span.textContent=letter;span.setAttribute('aria-hidden','true');return span;
 }));
 const glyphs=[...brand.children];
 const group=root.querySelector('.contact-group');
 group.after(group.cloneNode(true));
 const track=root.querySelector('.contact-track');
 let played=false,timer=0;
 const reveal=()=>{
  if(played||root.closest('[hidden]'))return;
  played=true;let index=0;
  if(reduced.matches){glyphs.forEach(g=>g.classList.add('printed'));return;}
  const print=()=>{glyphs[index++].classList.add('printed');if(index<glyphs.length)timer=setTimeout(print,140);};
  print();
 };
 const observer=new IntersectionObserver(entries=>{
  for(const entry of entries){
   if(entry.target===brand&&entry.isIntersecting)reveal();
   if(entry.target===track)track.style.animationPlayState=entry.isIntersecting?'running':'paused';
  }
 },{threshold:.25});
 observer.observe(brand);observer.observe(track);
 return {reset(){clearTimeout(timer);played=false;glyphs.forEach(g=>g.classList.remove('printed'));},dispose(){clearTimeout(timer);observer.disconnect();}};
}
