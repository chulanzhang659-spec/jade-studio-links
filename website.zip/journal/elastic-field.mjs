export const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
export const smoothValue=(current,target,dt,tau=110)=>current+(target-current)*(1-Math.exp(-clamp(dt,0,50)/tau));
export const pointerVelocity=(distance,ms)=>clamp(distance/Math.max(ms,1)*16,-42,42);
export const scrollArch=(u,progress)=>Math.sin(clamp(u,0,1)*Math.PI)*clamp(progress,0,1)*90;
export const loopPosition=(offset,start,length)=>((offset+start)%length+length)%length;
