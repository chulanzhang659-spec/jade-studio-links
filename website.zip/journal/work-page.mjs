import './correspondence-type.mjs';
import {createBusinessPanel} from './business-filters.mjs';
import {imageSlots} from './work-ribbon.mjs';
import {coverForProject} from './correspondence.mjs';
import {parseFolioState,targetState,folioURL,turnDirection} from './folio-model.mjs';
import {turnFolio} from './folio-turn.mjs';
import {mountContactField} from './contact-field-view.mjs';

const portfolios=window.JADE_CONTENT.portfolios;
const ids=portfolios.map(portfolio=>portfolio.id);
const shell=document.querySelector('#folio-shell');
const page=document.querySelector('#work-main');
const content=document.querySelector('#folio-content');
const reducedMotion=matchMedia('(prefers-reduced-motion: reduce)');
let state=parseFolioState(location.href,ids);
let contactField=null;

const escapeHTML=value=>String(value??'').replace(/[&<>'"]/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[char]));
const projectById=id=>portfolios.find(portfolio=>portfolio.id===id);
const turnLink=(target,label,direction,className='')=>target
 ?`<a class="folio-control ${className}" data-turn="${direction>0?'next':'previous'}" href="${folioURL(target)}">${escapeHTML(label)}</a>`
 :`<span class="folio-control ${className}" aria-disabled="true">${escapeHTML(label)}</span>`;
const glyphs=text=>[...text].map(char=>char===' '
 ?'<span class="contact-space" aria-hidden="true"></span>'
 :`<span data-contact-glyph aria-hidden="true">${escapeHTML(char)}</span>`).join('');

function returnLink(){
 let href='index.html#portfolio-index';
 try{
  const saved=JSON.parse(sessionStorage.getItem('jade-portfolio-return')||'null');
  if(saved?.path){const target=new URL(saved.path,location.href);if(target.origin===location.origin)href=target.pathname+target.search+'#portfolio-index';}
 }catch{/* The default archive link remains usable. */}
 document.querySelectorAll('.work-back').forEach(link=>{link.href=href;});
 return href;
}

function renderWork(nextState){
 const portfolio=projectById(nextState.id)||portfolios[0];
 const index=portfolios.indexOf(portfolio);
 const previous=targetState(nextState,-1,ids);
 const following=targetState(nextState,1,ids);
 const nextLabel=following?.view==='contact'?'联系我们 →':`${projectById(following?.id)?.subtitle||'下一份作品'} →`;
 const previousLabel=previous?`← ${projectById(previous.id)?.subtitle||'上一份作品'}`:'← 已是第一份';
 content.innerHTML=`
  <div class="folio-edition"><strong data-turn-text>JADE STUDIO</strong><span>SELECTED WORK / ${String(index+1).padStart(2,'0')} — ${String(portfolios.length).padStart(2,'0')}</span></div>
  <p class="folio-kicker turn-distort">JADE STUDIO / CREATIVE ATELIER / ${String(index+1).padStart(2,'0')}</p>
  <h1 class="folio-title turn-distort" data-turn-text>${escapeHTML(portfolio.title)}</h1>
  <section class="folio-deck"><h2 class="turn-distort" data-turn-text>${escapeHTML(portfolio.subtitle)}</h2><p class="turn-distort" data-turn-text>${escapeHTML(portfolio.body)}</p></section>
  <figure class="folio-hero"><img id="work-cover-image" alt="" fetchpriority="high"><figcaption id="work-cover-caption"></figcaption></figure>
  <section class="folio-collection" aria-labelledby="work-collection-title"><div class="folio-section-head"><h2 id="work-collection-title" class="turn-distort">作品集</h2><span class="folio-section-label">WORK INDEX / ARCHIVE</span></div><div id="work-gallery"></div></section>
  <nav class="folio-controls" aria-label="翻阅作品集"><span>TURN THE PAGE</span>${turnLink(previous,previousLabel,-1,'previous')}${turnLink(following,nextLabel,1,'next')}</nav>
  <section class="folio-contact-cta"><p class="turn-distort">想让新的故事，从这里开始？</p><a class="turn-distort" data-turn="contact" href="${folioURL({view:'contact',from:portfolio.id})}">联系我们 →</a></section>`;
 const slot=imageSlots.find(item=>item.id===portfolio.id),art=coverForProject(portfolio,slot);
 const cover=content.querySelector('#work-cover-image');cover.src=art.src;cover.alt=art.alt;cover.style.objectPosition=art.position;
 content.querySelector('#work-cover-caption').textContent=art.caption;
 content.querySelector('#work-gallery').append(createBusinessPanel(portfolio));
 document.title=`${portfolio.subtitle} — JADE STUDIO`;
}

function renderContact(nextState){
 const previous={view:'work',id:nextState.from};
 const previousPortfolio=projectById(nextState.from)||portfolios.at(-1);
 const archive=returnLink();
 content.innerHTML=`
  <section class="folio-contact-page" aria-labelledby="contact-heading">
   <p class="contact-overline">JADE STUDIO / CORRESPONDENCE / FINAL PAGE</p>
   <h1 class="contact-heading" id="contact-heading" aria-label="CONTACT US">${glyphs('CONTACT US')}</h1>
   <p class="contact-chinese" aria-label="联系我们">${glyphs('联系我们')}</p>
   <div class="contact-lines">
    <div class="contact-line"><span aria-label="TEL / 电话">${glyphs('TEL / 电话：')}</span><span class="contact-value" aria-label="电话号码空白"></span></div>
    <div class="contact-line"><span aria-label="EMAIL / 邮箱">${glyphs('EMAIL / 邮箱：')}</span><span class="contact-value" aria-label="邮箱地址空白"></span></div>
   </div>
   <footer class="contact-footer">${turnLink(previous,`← ${previousPortfolio.subtitle}`,-1,'previous')}<a href="${archive}">返回全部作品 ↗</a></footer>
  </section>`;
 document.title='联系我们 — JADE STUDIO';
 contactField=mountContactField(content.querySelector('.folio-contact-page'));
}

export function renderFolioState(nextState){
 contactField?.dispose();contactField=null;
 state=nextState;
 document.body.dataset.stage=state.view;
 page.dataset.view=state.view;
 if(state.view==='contact')renderContact(state);else renderWork(state);
 returnLink();
}

async function go(nextState,direction,{historyMode='push'}={}){
 if(!nextState||!direction||shell.dataset.turning==='true')return;
 const nextURL=folioURL(nextState);
 await turnFolio({
  shell,page,direction,
  reducedMotion:reducedMotion.matches,
  renderTarget:()=>renderFolioState(nextState),
  onCommit:()=>{
   if(historyMode==='push')history.pushState({folio:true},'',nextURL);
   const top=shell.getBoundingClientRect().top+scrollY-18;
   scrollTo({top:Math.max(0,top),behavior:'instant'});
  }
 });
}

shell.addEventListener('click',event=>{
 const control=event.target.closest('[data-turn]');
 if(!control||event.button!==0||event.metaKey||event.ctrlKey||event.shiftKey||event.altKey)return;
 const action=control.dataset.turn;
 let next;
 if(action==='contact'&&state.view==='work')next={view:'contact',from:state.id};
 else next=targetState(state,action==='previous'?-1:1,ids);
 if(!next)return;
 event.preventDefault();
 go(next,turnDirection(state,next,ids));
});

addEventListener('keydown',event=>{
 if(event.defaultPrevented||/INPUT|TEXTAREA|SELECT/.test(event.target.tagName))return;
 const direction=event.key==='ArrowRight'?1:event.key==='ArrowLeft'?-1:0;
 if(!direction)return;
 const next=targetState(state,direction,ids);if(!next)return;
 event.preventDefault();go(next,direction);
});

addEventListener('popstate',()=>{
 const next=parseFolioState(location.href,ids),direction=turnDirection(state,next,ids);
 if(direction)go(next,direction,{historyMode:'none'});else renderFolioState(next);
});

renderFolioState(state);
