import {galleryPosition,galleryExposure,easeScroll} from './arc-model.mjs?v=arc10';
import {CATEGORIES} from './categories.mjs?v=arc10';
import {artworkURL} from './artwork.js?v=arc10';
export function createGallery(host,{artworks,onSelect,onPaperSelect}){
 const field=host.querySelector('.gallery-field'),count=matchMedia('(max-width: 600px)').matches?90:126;
 const urls=artworks.map(artworkURL),items=[];
 for(let i=0;i<count;i++){
  const index=i%9,study=i%artworks.length,c=CATEGORIES[index],button=document.createElement('button');button.className='gallery-work';button.type='button';button.dataset.category=String(index);
  button.setAttribute('aria-label',`${c.label} · ${c.english} · 概念研究 ${study+1}`);
  const image=document.createElement('img');image.src=urls[study];image.alt='';image.width=1000;image.height=680;image.draggable=false;
  const caption=document.createElement('span');caption.textContent=`${c.id} — ${c.label} / ${c.english}`;button.append(image,caption);
  const item={button,image,i,study,category:index};
  button.addEventListener('click',()=>onSelect(index,artworks[item.study],button));field.append(button);items.push(item);
 }
 const motion=matchMedia('(prefers-reduced-motion: reduce)');
 let frame=0,disposed=false,current=null,last=performance.now(),elapsed=0,carried=null;
 const pointer={x:0,y:0},pointerTarget={x:0,y:0};
 function update(now=performance.now()){
  frame=0;if(disposed)return;const rect=host.getBoundingClientRect(),w=innerWidth,h=innerHeight,aspect=w/h,target=Math.max(0,-rect.top/h);
  const delta=now-last;
  const active=!motion.matches&&!document.hidden&&!host.closest('[hidden]')&&!document.querySelector('dialog[open]')&&rect.top<h&&rect.bottom>0&&!field.querySelector(':focus-visible');
  if(active)elapsed+=Math.min(Math.max(delta,0),50)/1000;
  current=easeScroll(current??target,target,motion.matches,delta);
  pointer.x=easeScroll(pointer.x,motion.matches?0:pointerTarget.x,false,delta);
  pointer.y=easeScroll(pointer.y,motion.matches?0:pointerTarget.y,false,delta);
  last=now;const progress=current;
  for(const item of items){
   const {button,image,i}=item;
   const p=galleryPosition(i,progress,aspect,motion.matches,w,items.length,pointer,elapsed);
   const exposure=galleryExposure(i,elapsed,motion.matches,artworks.length);
   if(item.study!==exposure.study){item.study=exposure.study;image.src=urls[item.study];const c=CATEGORIES[item.category];button.setAttribute('aria-label',`${c.label} · ${c.english} · 概念研究 ${item.study+1}`);}
   const width=w*p.relativeWidth;
   const halfHeight=p.relativeWidth*aspect*.34;
   const x=p.x+exposure.offsetX,y=Math.max(.35+halfHeight,p.y+exposure.offsetX*.4+exposure.offsetY);
   const opacity=p.opacity*exposure.opacity;
   button.style.width=`${width}px`;button.style.opacity=String(opacity);image.style.filter=exposure.blur>.01?`blur(${exposure.blur.toFixed(2)}px)`:'none';button.style.zIndex=String(10+p.z);button.style.transform=`translate3d(${x*w-width/2}px,${y*h-width*.34}px,0)`;
   const visible=rect.top<h&&rect.bottom>0&&opacity>.01&&x+p.relativeWidth/2>0&&x-p.relativeWidth/2<1&&y+halfHeight>0&&y-halfHeight<1;button.style.visibility=visible?'visible':'hidden';button.style.pointerEvents=opacity>.15?'auto':'none';button.tabIndex=visible&&opacity>.15?0:-1;
  }
  if(carried){
   const age=carried.held?0:elapsed-carried.started;
   const scroll=carried.held?0:current-carried.scroll;
   const dx=carried.held?0:(pointer.x-carried.pointer.x)*.08;
   const dy=carried.held?0:(pointer.y-carried.pointer.y)*.02;
   const raw=.53-age*.035-scroll*.85;
   const x=((raw+.4)%1.8+1.8)%1.8-.4;
   const y=.55+.40*x+dy,width=Math.min(w*.20,220),height=width*carried.ratio;
   carried.element.style.width=`${width}px`;
   carried.element.style.transform=`translate3d(${(x+dx)*w-width/2}px,${y*h-height/2}px,0)`;
   carried.element.style.opacity=carried.held?'0':String(Math.min(1,Math.max(0,(x+.15)/.18)));
   carried.element.style.pointerEvents=carried.held?'none':'auto';
  }
  if(active||current!==target||pointer.x!==(motion.matches?0:pointerTarget.x)||pointer.y!==(motion.matches?0:pointerTarget.y))frame=requestAnimationFrame(update);
 }
 function request(){if(!frame){last=performance.now();frame=requestAnimationFrame(update);}}
 function carryPaper(surface){
  carried?.element.remove();
  const element=document.createElement('button');element.className='gallery-work carried-paper';element.type='button';
  element.setAttribute('aria-label','作品集策划与设计');
  const image=document.createElement('img');image.src=artworkURL(surface);image.alt='';image.width=surface.width;image.height=surface.height;
  element.append(image);element.addEventListener('click',()=>onPaperSelect?.());field.append(element);
  carried={element,ratio:surface.height/surface.width,held:true,started:elapsed,scroll:current??0,pointer:{...pointer}};
  const item=carried;
  // Lay out the invisible receiving image synchronously before measuring it.
  cancelAnimationFrame(frame);update();
  return {element,release(){if(carried!==item)return;Object.assign(item,{held:false,started:elapsed,scroll:current??0,pointer:{...pointer}});request();},remove(){element.remove();if(carried===item)carried=null;}};
 }
 function move(event){
  const rect=host.getBoundingClientRect();
  if(event.pointerType==='touch'||motion.matches||document.querySelector('dialog[open]')||host.closest('[hidden]')||rect.top>=innerHeight||rect.bottom<=0)return;
  pointerTarget.x=event.clientX/innerWidth*2-1;pointerTarget.y=event.clientY/innerHeight*2-1;request();
 }
 function resetPointer(){pointerTarget.x=0;pointerTarget.y=0;request();}
 function leave(event){if(!event.relatedTarget)resetPointer();}
 window.addEventListener('pointermove',move,{passive:true});window.addEventListener('pointerout',leave);window.addEventListener('blur',resetPointer);
 document.addEventListener('visibilitychange',request);document.addEventListener('close',request,true);field.addEventListener('focusout',request);
 window.addEventListener('scroll',request,{passive:true});window.addEventListener('resize',request);motion.addEventListener('change',resetPointer);update();
 return {refresh:request,carryPaper,dispose(){disposed=true;cancelAnimationFrame(frame);carried?.element.remove();document.removeEventListener('visibilitychange',request);document.removeEventListener('close',request,true);field.removeEventListener('focusout',request);window.removeEventListener('pointermove',move);window.removeEventListener('pointerout',leave);window.removeEventListener('blur',resetPointer);window.removeEventListener('scroll',request);window.removeEventListener('resize',request);motion.removeEventListener('change',resetPointer);items.forEach(({button})=>button.remove());}};
}
