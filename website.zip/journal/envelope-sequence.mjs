const unit=n=>Math.max(0,Math.min(1,n));
const smooth=n=>{const t=unit(n);return t*t*(3-2*t);};
export const SEAL_DURATION=1280;
export function sealState(ms){
 const insert=smooth(ms/620),close=smooth((ms-620)/440),seal=smooth((ms-1060)/220);
 return {letterY:2-3.45*insert,letterVisible:close<1,flapAngle:Math.PI*close,flapZ:-.17+.49*close,sealScale:seal};
}
// CSS column-major projective transform: local rectangle -> projected mesh quad.
export function quadMatrix(width,height,[p0,p1,p2,p3]){
 const dx1=p1.x-p2.x,dx2=p3.x-p2.x,dx3=p0.x-p1.x+p2.x-p3.x;
 const dy1=p1.y-p2.y,dy2=p3.y-p2.y,dy3=p0.y-p1.y+p2.y-p3.y;
 const det=dx1*dy2-dx2*dy1;
 const g=Math.abs(det)>1e-10?(dx3*dy2-dx2*dy3)/det:0;
 const h=Math.abs(det)>1e-10?(dx1*dy3-dx3*dy1)/det:0;
 const a=p1.x-p0.x+g*p1.x,b=p3.x-p0.x+h*p3.x;
 const d=p1.y-p0.y+g*p1.y,e=p3.y-p0.y+h*p3.y;
 return [a/width,d/width,0,g/width,b/height,e/height,0,h/height,0,0,1,0,p0.x,p0.y,0,1];
}
