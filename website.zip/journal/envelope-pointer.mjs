export const ENVELOPE_POSE={x:.13,y:-.25,z:.14};
export function pointerPose(nx,ny){
 const x=Math.max(-1,Math.min(1,nx)),y=Math.max(-1,Math.min(1,ny));
 // The central area tilts subtly; moving towards either edge reveals the reverse.
 return {x:ENVELOPE_POSE.x+y*.34,y:ENVELOPE_POSE.y+Math.sign(x)*Math.pow(Math.abs(x),1.6)*Math.PI,z:ENVELOPE_POSE.z-x*.04};
}
export function easePose(current,target,dt){const a=1-Math.exp(-11*Math.min(.05,Math.max(0,dt)));return Object.fromEntries(['x','y','z'].map(k=>[k,current[k]+(target[k]-current[k])*a]));}
