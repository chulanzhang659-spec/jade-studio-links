// Shared with the cover's #ink-wear, without loading the homepage animation.
if(!document.getElementById('ink-wear')){
 const svg=document.createElementNS('http://www.w3.org/2000/svg','svg');
 svg.setAttribute('width','0');svg.setAttribute('height','0');svg.setAttribute('aria-hidden','true');svg.style.position='absolute';
 svg.innerHTML='<defs><filter id="ink-wear" x="-2%" y="-2%" width="104%" height="104%"><feTurbulence type="fractalNoise" baseFrequency=".19 .34" numOctaves="3" seed="17" result="grain"/><feColorMatrix in="grain" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 24 -6.4" result="ink"/><feComposite in="SourceGraphic" in2="ink" operator="in"/></filter></defs>';
 document.body.prepend(svg);
}
