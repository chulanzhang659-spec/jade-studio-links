import './correspondence-type.mjs';
import {mountEnvelope3D} from './envelope-three.mjs';
import {workURL} from './portfolio-exit.mjs';
const $=selector=>document.querySelector(selector);
let envelope=null,sceneGeneration=0;
async function startEnvelope(){const run=++sceneGeneration;try{const model=await mountEnvelope3D($('.envelope-scene'));if(run!==sceneGeneration){model.dispose();return;}envelope=model;}catch{/* Closed CSS envelope is the accessible static fallback. */}}
startEnvelope();
window.addEventListener('pagehide',()=>{sceneGeneration++;envelope?.dispose();envelope=null;});
window.addEventListener('pageshow',event=>{if(event.persisted)startEnvelope();});
const id=new URL(location.href).searchParams.get('project');
const portfolio=window.JADE_CONTENT.portfolios.find(p=>p.id===id);
if(portfolio){$('#contact-back').href=workURL(id)+'&from=contact';document.title=`联系 / ${portfolio.subtitle} — JADE STUDIO`;}
else try{const home=JSON.parse(sessionStorage.getItem('jade-portfolio-return')||'null');if(home?.path){const url=new URL(home.path,location.href);if(url.origin===location.origin)$('#contact-back').href=url.pathname+url.search+'#portfolio-index';}}catch{/* Keep the static back route. */}
