const PROJECT_ID=/^portfolio-\d{2}$/;

export function validProject(id,ids){return typeof id==='string'&&PROJECT_ID.test(id)&&ids.includes(id);}

export function parseFolioState(input,ids){
 const url=input instanceof URL?input:new URL(input,globalThis.location?.href||'https://jade.local/');
 const from=url.searchParams.get('from');
 if(url.searchParams.get('view')==='contact'&&validProject(from,ids))return {view:'contact',from};
 const id=url.searchParams.get('project');
 return {view:'work',id:validProject(id,ids)?id:ids[0]};
}

export function targetState(state,direction,ids){
 if(state.view==='contact')return direction<0&&validProject(state.from,ids)?{view:'work',id:state.from}:null;
 const index=ids.indexOf(state.id);
 if(index<0)return null;
 if(direction>0)return index===ids.length-1?{view:'contact',from:state.id}:{view:'work',id:ids[index+1]};
 return index>0?{view:'work',id:ids[index-1]}:null;
}

export function folioURL(state){
 if(state?.view==='contact'&&PROJECT_ID.test(state.from||''))return `work.html?view=contact&from=${encodeURIComponent(state.from)}`;
 if(state?.view==='work'&&PROJECT_ID.test(state.id||''))return `work.html?project=${encodeURIComponent(state.id)}`;
 return 'work.html';
}

export function turnDirection(from,to,ids){
 if(!from||!to)return 0;
 if(from.view==='work'&&to.view==='contact')return 1;
 if(from.view==='contact'&&to.view==='work')return -1;
 const a=ids.indexOf(from.id),b=ids.indexOf(to.id);
 return a<0||b<0||a===b?0:Math.sign(b-a);
}
