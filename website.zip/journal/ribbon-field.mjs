import {clamp,loopPosition} from './elastic-field.mjs';

export function rippleOffset(x,y,phase){
 if(phase<=0||(!x&&!y))return {x:0,y:0};
 const r=Math.hypot(x,y);let wave=0;
 for(let i=0;i<3;i++){const t=phase-i*.065;if(t<=0)continue;const front=r-t*1800;wave+=Math.sin(front*.06)*Math.exp(-Math.pow(front/80,2))*Math.exp(-t*4.5)*10*Math.min(t/.022,1);}
 return {x:x/Math.max(1,r)*wave,y:y/Math.max(1,r)*wave};
}

// All image vertices share this field. Adjacent edges remain joined, unlike
// independent card rotations. Keep the GLSL counterpart in ribbon-renderer in sync.
export function deformPoint(x,y,s){
 const dx=x-s.mx,dy=y-s.my,radius=Math.max(150,Math.min(280,s.width*.18));
 const local=Math.exp(-(dx*dx+dy*dy)/(radius*radius));
 let px=x+local*(dx*.22*s.hover+s.pullX),py=y+local*(dy*.3*s.hover+s.pullY);
 py-=Math.sin(clamp(x/s.width,0,1)*Math.PI)*s.arch;
 if(s.ripple>0){
  const wave=rippleOffset(x-s.rippleX,y-s.rippleY,s.ripple);
  px+=wave.x;py+=wave.y;
 }
 return {x:px+(s.shiftX||0),y:py};
}
export function inversePoint(x,y,s){
 let px=x,py=y;
 for(let i=0;i<18;i++){const q=deformPoint(px,py,s);px+=x-q.x;py+=y-q.y;}
 return {x:px,y:py};
}
export function ribbonLayout(width,height,offset,slots){
 const count=slots.length,cw=width<=600?width*.72:width*.29,total=cw*count;
 const shift=loopPosition(offset,0,total)-cw*.35,first=Math.floor(-shift/cw)-1,rows=[];
 for(let j=first;j<first+Math.ceil(width/cw)+3;j++){
  const x=j*cw+shift,index=((j%count)+count)%count;
  // A strong screen-space descending lower edge: left highest, right lowest.
  const h=height*(.58+.4*clamp((x+cw*.5)/width,0,1));
  rows.push({index,x,y:0,width:cw,height:h});
 }
 return rows;
}
export function hitRibbon(x,y,rows,state){
 const p=inversePoint(x,y,state);
 return rows.find(r=>p.x>=r.x&&p.x<r.x+r.width&&p.y>=r.y&&p.y<=r.y+r.height);
}

// Both the portfolio band and the logo/copy use this exact deformation.
export const rippleGLSL=`vec2 rippleOffset(vec2 p){vec2 rd=p-uOrigin;float r=length(rd),wave=0.;for(int i=0;i<3;i++){float t=uRipple-float(i)*.065;float front=r-max(t,0.)*1800.;wave+=sin(front*.06)*exp(-pow(front/80.,2.))*exp(-max(t,0.)*4.5)*10.*clamp(t/.022,0.,1.);}return rd/max(1.,r)*wave;}`;
export const ribbonVertexShader=`varying vec2 vUv,vPaperPoint;uniform vec2 uSize,uMouse,uPull,uOrigin;uniform vec4 uRect;uniform float uHover,uArch,uRipple,uShift;
 ${rippleGLSL}
 void main(){vUv=uv;vec2 p=vec2(uRect.x+(position.x+.5)*uRect.z,uRect.y+(.5-position.y)*uRect.w);vPaperPoint=p;
  vec2 d=p-uMouse;float radius=clamp(uSize.x*.18,150.,280.);float local=exp(-dot(d,d)/(radius*radius));
  vec2 q=p+local*(d*vec2(.22,.3)*uHover+uPull);
  q.y-=sin(clamp(p.x/uSize.x,0.,1.)*3.14159265)*uArch;
  q+=rippleOffset(p);q.x+=uShift;
  gl_Position=vec4(q.x/uSize.x*2.-1.,1.-q.y/uSize.y*2.,0.,1.);
 }`;
