const clamp01=value=>Math.min(1,Math.max(0,Number.isFinite(value)?value:0));

export function creasePosition(progress){
 return 1-clamp01(progress);
}

export function crumpleProfile(u,progress,pointerY=.5,velocity=0){
 const x=clamp01(u);
 const turn=clamp01(progress);
 if(turn===0||x===0)return {x,z:0,bend:0,visible:true};

 const crease=creasePosition(turn);
 if(x>crease)return {x,z:0,bend:0,visible:false};

 const distance=crease-x;
 const trail=.18+.82*Math.exp(-distance*3.6);
 const height=(clamp01(pointerY)-.5)*Math.PI;
 const speed=Math.min(.55,Math.abs(velocity)*.09);
 const wrinkle=Math.sin(distance*31+height*2.4)*.58+Math.sin(distance*67-height*4.1)*.27+Math.sin(distance*14+height)*.15;
 const bend=turn*trail*(1.18+speed);
 const z=wrinkle*bend*.105;

 return {
  x:Math.max(0,x-turn*(.06+.1*trail)*x),
  z,
  bend,
  visible:true
 };
}

export function pageTurnPhase(progress){
 const turn=clamp01(progress);
 return turn===0?'rest':turn===1?'complete':'partial';
}
