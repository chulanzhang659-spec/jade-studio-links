export const PORTFOLIO_EXIT_MS=460;
const smooth=(a,b,t)=>{const p=Math.max(0,Math.min(1,(t-a)/(b-a)));return p*p*(3-2*p);};
export function portfolioExit(ms){return {others:1-smooth(70,240,ms),selected:1-smooth(310,460,ms),surround:1-smooth(90,280,ms),done:ms>=PORTFOLIO_EXIT_MS};}
export function workURL(id){return /^portfolio-0[1-6]$/.test(id)?`work.html?project=${id}`:null;}
