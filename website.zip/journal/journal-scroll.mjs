// Same time-based damping used by the Motion site's river (90 ms response).
export function easeScroll(current,target,reducedMotion=false,delta=16.67){
 if(reducedMotion||Math.abs(target-current)<.0001)return target;
 return current+(target-current)*(1-Math.exp(-Math.min(Math.max(delta,0),80)/90));
}
export const dragOffset=(target,current)=>Math.max(-90,Math.min(90,target-current));
export function createScrollDrag(host,{isActive=()=>true}={}){
 const motion=matchMedia('(prefers-reduced-motion: reduce)');
 let frame=0,current=scrollY,last=performance.now();
 function reset(){cancelAnimationFrame(frame);frame=0;current=scrollY;host.style.transform='';host.style.willChange='';}
 function tick(now){
  frame=0;
  if(!isActive()||motion.matches||document.hidden){reset();return;}
  const target=scrollY;
  current=easeScroll(current,target,false,now-last);last=now;
  const offset=dragOffset(target,current);
  host.style.transform=Math.abs(offset)>.05?`translate3d(0,${offset}px,0)`:'';
  if(Math.abs(target-current)>.05)frame=requestAnimationFrame(tick);
  else{current=target;host.style.willChange='';}
 }
 function request(){if(!frame&&isActive()&&!motion.matches){last=performance.now();host.style.willChange='transform';frame=requestAnimationFrame(tick);}}
 window.addEventListener('scroll',request,{passive:true});
 window.addEventListener('resize',reset);window.addEventListener('pagehide',reset);
 document.addEventListener('visibilitychange',reset);motion.addEventListener('change',reset);
 return {reset,dispose(){reset();window.removeEventListener('scroll',request);window.removeEventListener('resize',reset);window.removeEventListener('pagehide',reset);document.removeEventListener('visibilitychange',reset);motion.removeEventListener('change',reset);}};
}
