const clamp=(n,a,b)=>Math.max(a,Math.min(b,n));
export function textInkTop(box,ink){return box.baseline===undefined?box.top+(box.height-ink.height)/2:box.baseline-ink.ascent;}
export function letterField(x,row,p,now){
 if(!p)return {dx:0,dy:0,scale:1};
 const distanceX=Math.max(row.left-p.x,0,p.x-row.left-row.width);
 const distanceY=Math.max(row.top-p.y,0,p.y-row.top-row.height);
 const proximity=Math.max(0,1-Math.hypot(distanceX,distanceY)/65);
 if(!proximity)return {dx:0,dy:0,scale:1};
 const local=Math.exp(-Math.pow((x-(p.x-row.left))/Math.max(45,row.height*1.5),2));
 const decay=Math.max(0,1-Math.max(0,now-p.at-70)/330);
 const hover=Math.max(0,1-Math.hypot(distanceX,distanceY)/12);
 return {dx:decay?clamp(p.vx,-10,10)*.6*local*proximity*decay:0,
  dy:decay?clamp(p.vy,-10,10)*.85*local*proximity*decay:0,
  scale:1+.24*local*hover};
}

export function createManifestoMotion(section,{isActive}){
 const reduced=matchMedia('(prefers-reduced-motion: reduce)'),fine=matchMedia('(hover: hover) and (pointer: fine)');
 let rows=[],pointer=null,raf=0,last=0;
 const enabled=()=>isActive()&&!reduced.matches&&fine.matches&&!document.hidden;
 function clear(){
  cancelAnimationFrame(raf);raf=0;last=0;pointer=null;
  rows.forEach(r=>{r.node.style.opacity='';r.canvas.remove();});rows=[];
 }
 function refresh(){
  clear();if(!enabled())return;
  const sectionBox=section.getBoundingClientRect(),dpr=Math.min(devicePixelRatio||1,2);
  for(const node of section.querySelectorAll('#manifesto-type text,.manifesto-chinese')){
   const style=getComputedStyle(node),font=parseFloat(style.fontSize),text=node.textContent;
   const source=document.createElement('canvas'),ink=source.getContext('2d');if(!ink)continue;
   const fontSpec=`${style.fontWeight} ${font}px ${style.fontFamily}`;
   ink.font=fontSpec;ink.letterSpacing=style.letterSpacing==='normal'?'0px':style.letterSpacing;
   const m=ink.measureText(text),isSVG=node.namespaceURI==='http://www.w3.org/2000/svg';
   const rect=node.getBoundingClientRect(),width=Math.ceil(m.width),height=Math.ceil(m.actualBoundingBoxAscent+m.actualBoundingBoxDescent);
   if(!width||!height)continue;
   const left=rect.left-sectionBox.left+(rect.width-width)/2;
   // SVG text bounds contain its ascender; HTML uses a line box with half-leading.
   const top=textInkTop({baseline:isSVG?Number(node.getAttribute('y')):undefined,top:rect.top-sectionBox.top,height:rect.height},{ascent:m.actualBoundingBoxAscent,height});
   const pad=Math.ceil(font*.65),canvas=document.createElement('canvas'),ctx=canvas.getContext('2d');if(!ctx)continue;
   for(const c of [source,canvas]){c.width=Math.ceil((width+2*pad)*dpr);c.height=Math.ceil((height+2*pad)*dpr);}
   ink.setTransform(dpr,0,0,dpr,0,0);ink.font=fontSpec;ink.letterSpacing=style.letterSpacing==='normal'?'0px':style.letterSpacing;
   ink.fillStyle=isSVG?style.fill:style.color;ink.fillText(text,pad,pad+m.actualBoundingBoxAscent);
   canvas.className='manifesto-motion-canvas';canvas.setAttribute('aria-hidden','true');
   Object.assign(canvas.style,{position:'absolute',pointerEvents:'none',left:`${left-pad}px`,top:`${top-pad}px`,width:`${width+2*pad}px`,height:`${height+2*pad}px`,filter:isSVG?'url(#ink-wear)':'none'});
   section.append(canvas);
   const count=Math.ceil(width/2);
   rows.push({node,canvas,ctx,source,left,top,width,height,pad,dpr,count,values:Array.from({length:count},()=>({dx:0,dy:0,scale:1}))});
  }
  draw(performance.now());
 }
 function draw(now){
  raf=0;const ease=1-Math.exp(-Math.min(now-(last||now-16),50)/65);last=now;
  const allowed=enabled(),bounds=section.getBoundingClientRect();let moving=false;
  for(const r of rows){
   const absolute={...r,left:r.left+bounds.left,top:r.top+bounds.top};
   const step=r.width/r.count;let changed=false;
   r.ctx.setTransform(r.dpr,0,0,r.dpr,0,0);r.ctx.clearRect(0,0,r.width+2*r.pad,r.height+2*r.pad);
   for(let i=0;i<r.count;i++){
    const x=(i+.5)*step,target=letterField(x,absolute,allowed?pointer:null,now),value=r.values[i];
    for(const k of ['dx','dy','scale']){
     value[k]+=(target[k]-value[k])*ease;
     if(Math.abs(value[k]-target[k])>.001)moving=true;else value[k]=target[k];
    }
    if(Math.abs(value.dx)>.01||Math.abs(value.dy)>.01||Math.abs(value.scale-1)>.001)changed=true;
    r.ctx.drawImage(r.source,(r.pad+i*step)*r.dpr,0,(step+.4)*r.dpr,r.source.height,
     r.pad+i*step+value.dx,r.pad+value.dy-(r.height*value.scale-r.height)/2-r.pad*value.scale,
     step+.4,(r.height+2*r.pad)*value.scale);
   }
   r.canvas.hidden=!changed;r.node.style.opacity=changed?'0':'';
  }
  if(moving||(allowed&&pointer&&now-pointer.at<420))raf=requestAnimationFrame(draw);else last=0;
 }
 function wake(){if(!raf)raf=requestAnimationFrame(draw);}
 function move(event){
  if(!enabled()||event.pointerType==='touch')return;
  const now=performance.now(),recent=pointer&&now-pointer.at<100;
  pointer={x:event.clientX,y:event.clientY,vx:recent?event.clientX-pointer.x:0,vy:recent?event.clientY-pointer.y:0,at:now};wake();
 }
 function reset(){pointer=null;wake();}
 section.addEventListener('pointermove',move,{passive:true});section.addEventListener('pointerdown',move,{passive:true});section.addEventListener('pointerleave',reset);
 window.addEventListener('scroll',reset,{passive:true});window.addEventListener('blur',reset);
 document.addEventListener('visibilitychange',reset);reduced.addEventListener('change',refresh);fine.addEventListener('change',refresh);
 const observer=new MutationObserver(()=>{if(!enabled())clear();else if(!rows.length)refresh();});observer.observe(document.body,{attributes:true,attributeFilter:['data-stage','class']});
 return {refresh,dispose(){clear();observer.disconnect();section.removeEventListener('pointermove',move);section.removeEventListener('pointerdown',move);section.removeEventListener('pointerleave',reset);window.removeEventListener('scroll',reset);window.removeEventListener('blur',reset);document.removeEventListener('visibilitychange',reset);reduced.removeEventListener('change',refresh);fine.removeEventListener('change',refresh);}};
}
