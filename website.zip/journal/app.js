(() => {
  const content = window.JADE_CONTENT;
  const paper = document.querySelector('.paper');
  const dialog = document.querySelector('#story-dialog');
  const storyContent = document.querySelector('#story-content');
  const wipe = document.querySelector('.paper-wipe');
  const skip = document.querySelector('#skip-intro');
  const printStage = document.querySelector('#print-stage');
  const printOpen = document.querySelector('#print-open');
  const printStatus = document.querySelector('#print-status');
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)');
  let intro, turnDelay, transition, opener, busy = false, introPlaying = false;
  if ('scrollRestoration' in history) history.scrollRestoration = 'manual';
  const escapeHTML = value => String(value).replace(/[&<>"']/g, char => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[char]));
  const portfolioGrid = document.querySelector('#portfolio-grid');
  content.portfolios.forEach((portfolio,index)=>{
    const number=String(index+1).padStart(2,'0');
    const asset=portfolio.image&&content.images[portfolio.image];
    content.stories[portfolio.id]={eyebrow:`STUDIO ARCHIVE / ${number} OF 08`,title:escapeHTML(portfolio.title),body:escapeHTML(portfolio.body),note:portfolio.status==='COMING SOON'?'作品集待更新 / Collection coming soon.':'Illustrative concept — imagery and copy will be replaced with studio work.',portfolio};
    const button=document.createElement('button');
    button.className='portfolio-entry';
    button.dataset.open=portfolio.id;
    button.dataset.preview=String(index===0);
    button.setAttribute('aria-label',`Open ${portfolio.title}`);
    const spineTitle=asset?portfolio.subtitle:`Collection ${number}`;
    button.innerHTML=`<span class="portfolio-spine"><span class="spine-number">${number}</span><span class="spine-title">${escapeHTML(spineTitle)}</span><span class="spine-arrow">↗</span></span><span class="portfolio-preview"><span class="portfolio-topline"><span>${escapeHTML(portfolio.title)} / JADE STUDIO</span><span>${escapeHTML(portfolio.status)}</span></span><span class="portfolio-cover ${asset?'has-art':'reserved-cover'}">${asset?`<img src="${escapeHTML(asset.src)}" style="object-position:${escapeHTML(asset.position)}" alt="${escapeHTML(portfolio.subtitle)} — concept illustration" loading="lazy">`:`<span class="reserved-number">${number}</span><span class="reserved-label">THIS PAGE IS RESERVED<br>FOR WHAT COMES NEXT.</span>`}</span><span class="portfolio-caption"><span class="portfolio-title">${escapeHTML(spineTitle)}<span>↗</span></span><span class="portfolio-subtitle">${asset?'A study in silhouette, texture & feeling.':'A collection in the making. Work coming soon.'}</span><span class="portfolio-open-label">OPEN COLLECTION</span></span></span>`;
    portfolioGrid.append(button);
    const preview=()=>portfolioGrid.querySelectorAll('.portfolio-entry').forEach(entry=>{entry.dataset.preview=String(entry===button);});
    button.addEventListener('pointerenter',event=>{if(event.pointerType==='mouse')preview();});
    button.addEventListener('focus',preview);
  });
  document.querySelectorAll('[data-image]').forEach(img => {
    const data = content.images[img.dataset.image];
    img.src = data.src;
    img.style.objectPosition = data.position;
  });
  function finishIntro() {
    intro?.kill();
    turnDelay?.kill();
    if (window.gsap) gsap.set(paper, {clearProps:'transform,opacity,willChange,clipPath'});
    printStage.hidden = true;
    printOpen.disabled = true;
    document.body.classList.remove('intro-active');
    paper.inert = false;
    paper.dataset.introPhase = 'complete';
    document.body.style.overflow = '';
    skip.hidden = true;
    if(introPlaying) window.scrollTo({top:0,behavior:'instant'});
    introPlaying = false;
  }
  function playIntro() {
    if (!window.gsap || reduce.matches) return finishIntro();
    intro?.kill();
    turnDelay?.kill();
    gsap.set(paper,{clearProps:'transform,opacity,willChange,clipPath'});
    introPlaying = true;
    window.scrollTo({top:0,behavior:'instant'});
    document.body.style.overflow = 'hidden';
    document.body.classList.add('intro-active');
    paper.inert = true;
    skip.hidden = false;
    printStage.hidden = false;
    printOpen.disabled = true;
    printStatus.textContent = 'PRINTING THE STUDIO JOURNAL…';
    paper.dataset.introPhase = 'printing';
    const rect = paper.getBoundingClientRect();
    const scale = Math.min(.68,window.innerHeight*.68/rect.height);
    const slot = window.innerHeight*.90;
    const startY = slot-rect.top-rect.height*(1-scale)/2;
    // Stop after one third has emerged; keep the remaining paper inside the slot.
    const endY = startY-rect.height*scale/3;
    intro = gsap.timeline({onComplete:()=>{
      paper.dataset.introPhase = 'waiting';
      printStatus.textContent = 'CLICK TO UNFOLD · OPENING IN A MOMENT';
      printOpen.disabled = false;
      turnDelay = gsap.delayedCall(1,unfoldPaper);
    }});
    intro.fromTo(paper,{y:startY,scale,rotation:0,opacity:1,clipPath:'inset(0% 0% 100% 0%)'},
      {y:endY,clipPath:'inset(0% 0% 66.666667% 0%)',duration:3.2,ease:'none'});
  }
  function unfoldPaper(){
    if(paper.dataset.introPhase!=='waiting')return;
    turnDelay?.kill();
    intro?.kill();
    paper.dataset.introPhase='unfolding';
    printStage.hidden=true;
    intro=gsap.timeline({onComplete:finishIntro});
    intro.to(paper,{rotation:360,scale:1,y:0,clipPath:'inset(0% 0% 0% 0%)',duration:1.6,ease:'power3.inOut'});
  }
  function animatePaper(change) {
    if(busy)return;
    if(!window.gsap || reduce.matches){change();return;}
    busy=true;
    transition=gsap.timeline({onComplete:()=>{busy=false;gsap.set(wipe,{visibility:'hidden'});}});
    transition.set(wipe,{visibility:'visible',yPercent:110,rotation:-5})
      .to(wipe,{yPercent:0,rotation:0,duration:.38,ease:'power2.inOut'})
      .call(change)
      .to(wipe,{yPercent:-120,rotation:3,duration:.5,ease:'power2.inOut'},'+=.06');
  }
  function openStory(key,trigger) {
    if(busy)return;
    finishIntro();
    const story=content.stories[key];
    if(!story)return;
    opener=trigger;
    animatePaper(()=>{
      const asset=story.image && content.images[story.image];
      storyContent.innerHTML=`<p class="story-eyebrow">${story.eyebrow}</p><h2 class="story-heading" id="story-title">${story.title}</h2>${asset?`<img class="story-image" src="${asset.src}" style="object-position:${asset.position}" alt="${story.title} — illustrated concept study">`:''}<p class="story-body">${story.body}</p><p class="story-note">${story.note}</p>${story.action?`<button class="story-action" id="explore-work">${story.action}</button>`:''}`;
      if(story.portfolio){
        const portfolio=story.portfolio;
        const cover=portfolio.image&&content.images[portfolio.image];
        const gallery=portfolio.gallery.length?portfolio.gallery:(cover?[{src:cover.src,alt:portfolio.subtitle,caption:'CONCEPT IMAGE / TO BE REPLACED'}]:[]);
        const section=document.createElement('div');
        section.className='portfolio-gallery';
        section.innerHTML=gallery.length?gallery.map(item=>`<figure><img src="${escapeHTML(item.src)}" alt="${escapeHTML(item.alt||portfolio.title)}"><figcaption>${escapeHTML(item.caption||'')}</figcaption></figure>`).join(''):'<div class="gallery-reserved"><span>WORK COMING SOON</span><p>作品将在此处展示。</p></div>';
        storyContent.append(section);
      }
      dialog.showModal();
      dialog.scrollTop=0;
      document.body.classList.add('modal-open');
      document.querySelector('#explore-work')?.addEventListener('click',()=>{
        closeStory();document.querySelector('#portfolio-index').scrollIntoView({behavior:reduce.matches?'instant':'smooth',block:'start'});
      });
    });
  }
  function closeStory(){dialog.close();document.body.classList.remove('modal-open');opener?.focus({preventScroll:true});}
  document.querySelectorAll('[data-open]').forEach(button=>button.addEventListener('click',()=>openStory(button.dataset.open,button)));
  document.querySelector('#close-dialog').addEventListener('click',closeStory);
  document.querySelector('#back-journal').addEventListener('click',closeStory);
  dialog.addEventListener('cancel',event=>{event.preventDefault();closeStory();});
  dialog.addEventListener('click',event=>{if(event.target===dialog){const rect=dialog.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)closeStory();}});
  skip.addEventListener('click',finishIntro);
  printOpen.addEventListener('click',unfoldPaper);
  document.querySelector('#replay').addEventListener('click',playIntro);
  reduce.addEventListener('change',()=>{if(reduce.matches){finishIntro();transition?.kill();busy=false;wipe.style.visibility='hidden';}});
  document.addEventListener('keydown',event=>{if(event.key==='Escape'&&!skip.hidden)finishIntro();});
  // Print first; only rotate after the one-second pause or an explicit click.
  playIntro();
})();
