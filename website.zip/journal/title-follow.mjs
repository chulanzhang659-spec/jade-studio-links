// Local preview only. Continuous strip deformation keeps the chosen letterforms.
const clamp=(n,min=-1,max=1)=>Math.max(min,Math.min(max,n));
export function titleSlice(u,p,height){
 const x=clamp(p.x),y=clamp(p.y),a=clamp(p.active,0,1);
 const local=Math.exp(-Math.pow((u-(x+1)/2)/.24,2));
 return {dx:x*height*14/100*a,dy:y*height*(.09+.25*local)*a,scaleY:1+.22*local*a};
}

export async function createTitleFollow(title,intro){
 const reduced=matchMedia('(prefers-reduced-motion: reduce)');
 const fine=matchMedia('(hover: hover) and (pointer: fine)');
 await document.fonts.ready;
 if(!title.isConnected)return;
 const original=document.createElement('span');
 original.className='title-follow-original';
 while(title.firstChild)original.append(title.firstChild);
 title.append(original);
 const canvas=document.createElement('canvas'),source=document.createElement('canvas');
 canvas.setAttribute('aria-hidden','true');canvas.className='title-follow-canvas';
 const ctx=canvas.getContext('2d'),ink=source.getContext('2d');
 if(!ctx||!ink){original.replaceWith(...original.childNodes);return;}
 Object.assign(title.style,{position:'relative',filter:'none'});
 Object.assign(canvas.style,{position:'absolute',pointerEvents:'none',filter:'url(#ink-wear)'});
 title.append(canvas);
 let width=0,height=0,pad=0,dpr=1,raf=0,last=0,disposed=false;
 const current={x:0,y:0,active:0},target={x:0,y:0,active:0};
 const enabled=()=>fine.matches&&!reduced.matches&&document.body.dataset.stage==='intro'&&!document.hidden;
 function draw(){
  ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,width+2*pad,height+2*pad);
  // All slices share one smooth field, so letter edges curve rather than rotate independently.
  const count=Math.ceil(width*dpr/2),step=width/count;
  for(let i=0;i<count;i++){
   const x=i*step,{dx,dy,scaleY}=titleSlice((i+.5)/count,current,height);
   ctx.drawImage(source,(pad+x)*dpr,0,(step+.4)*dpr,source.height,
    pad+x+dx,pad+dy-(height*scaleY-height)/2-pad*scaleY,step+.4,(height+2*pad)*scaleY);
  }
 }
 function resize(){
  if(disposed||intro.hidden)return;
  const rect=original.getBoundingClientRect(),style=getComputedStyle(title);
  width=rect.width;height=rect.height;if(!width||!height)return;
  pad=Math.ceil(height*.8);dpr=Math.min(devicePixelRatio||1,2);
  for(const c of [canvas,source]){c.width=Math.ceil((width+2*pad)*dpr);c.height=Math.ceil((height+2*pad)*dpr);}
  Object.assign(canvas.style,{left:`${-pad}px`,top:`${-pad}px`,width:`${width+2*pad}px`,height:`${height+2*pad}px`});
  ink.setTransform(dpr,0,0,dpr,0,0);
  ink.font=`${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
  ink.fillStyle=style.color;ink.textBaseline='alphabetic';
  const text=original.textContent.replace(/\s+/g,' ').trim(),spacing=parseFloat(style.letterSpacing)||0;
  const advances=[...text].map(c=>ink.measureText(c).width+spacing);
  const fit=width/advances.reduce((a,b)=>a+b,0),cap=ink.measureText('A').actualBoundingBoxAscent;
  const baseline=pad+(height+cap)/2;
  let x=pad;
  [...text].forEach((c,i)=>{
   ink.save();ink.translate(x,baseline);ink.scale(fit,1);
   if(c==='J'){ink.translate(0,-cap);ink.scale(1,.747301);ink.translate(0,cap);}
   ink.fillText(c,0,0);ink.restore();x+=advances[i]*fit;
  });
  sync();
 }
 function tick(now){
  raf=0;const ease=1-Math.exp(-Math.min(now-(last||now-16),50)/140);last=now;
  let moving=false;
  for(const key of ['x','y','active']){
   current[key]+=(target[key]-current[key])*ease;
   if(Math.abs(target[key]-current[key])>.001)moving=true;else current[key]=target[key];
  }
  draw();if(moving)raf=requestAnimationFrame(tick);else last=0;
 }
 function wake(){if(!raf&&!disposed)raf=requestAnimationFrame(tick);}
 function reset(){target.x=0;target.y=0;target.active=0;wake();}
 function pointer(event){
  if(!enabled()||event.pointerType==='touch')return;
  const rect=original.getBoundingClientRect();
  target.x=clamp((event.clientX-rect.left-rect.width/2)/(rect.width/2));
  target.y=clamp((event.clientY-rect.top-rect.height/2)/(rect.height*3));
  target.active=1;wake();
 }
 function sync(){
  const active=enabled();canvas.hidden=!active;original.style.visibility=active?'hidden':'';
  original.style.filter=active?'none':'url(#ink-wear)';
  if(!active){cancelAnimationFrame(raf);raf=0;last=0;for(const k of ['x','y','active'])current[k]=target[k]=0;}
  else draw();
 }
 const observer=new MutationObserver(()=>{sync();if(!intro.hidden)resize();});
 observer.observe(document.body,{attributes:true,attributeFilter:['data-stage']});
 const sizes=new ResizeObserver(resize);sizes.observe(title);
 intro.addEventListener('pointermove',pointer,{passive:true});intro.addEventListener('pointerleave',reset);
 window.addEventListener('blur',reset);document.addEventListener('visibilitychange',sync);
 reduced.addEventListener('change',sync);fine.addEventListener('change',sync);
 resize();
 return {dispose(){disposed=true;cancelAnimationFrame(raf);observer.disconnect();sizes.disconnect();
  intro.removeEventListener('pointermove',pointer);intro.removeEventListener('pointerleave',reset);
  window.removeEventListener('blur',reset);document.removeEventListener('visibilitychange',sync);
  reduced.removeEventListener('change',sync);fine.removeEventListener('change',sync);
  canvas.remove();original.replaceWith(...original.childNodes);title.style.filter='';title.style.position='';
 }};
}
