const finite=(value,fallback)=>Number.isFinite(value)?value:fallback;

export function pageFrame(viewWidth,viewHeight,{
 fov=34,
 distance=10.4,
 pageWidth=5.9,
 pageHeight=7.5,
 coverage=.92
}={}){
 const width=Math.max(1,finite(viewWidth,1));
 const height=Math.max(1,finite(viewHeight,1));
 const safeFov=Math.max(1,finite(fov,34));
 const safeDistance=Math.max(.1,finite(distance,10.4));
 const visibleHeight=2*Math.tan(safeFov*Math.PI/360)*safeDistance;
 const visibleWidth=visibleHeight*(width/height);
 const coverageX=Math.min(.98,Math.max(.9,finite(coverage,.92)));
 const scale=(visibleWidth*coverageX)/pageWidth;
 const renderedHeight=pageHeight*scale;
 const pageTop=visibleHeight*.49;
 const centerY=pageTop-renderedHeight/2;
 return {
  visibleWidth,
  visibleHeight,
  coverageX,
  scaleX:scale,
  scaleY:scale,
  centerY,
  pageTop,
  pageBottom:centerY-renderedHeight/2
 };
}
