// Replace any source independently. position and detailPosition control the crop.
// Every visible text remains HTML, separate from these image files.
window.JADE_CONTENT = {
  images: {
    hero: {src: 'assets/editorial-hero.png', position: '50% 0%'},
    portrait: {src: 'assets/editorial-hero.png', position: '52% 0%'},
    drape: {src: 'assets/editorial-hero.png', position: '70% 46%'},
    tailoring: {src: 'assets/editorial-hero.png', position: '40% 73%'}
  },
  // Eight independently editable portfolio channels. Add real gallery images as ready.
  // gallery accepts {src, alt, caption}; an empty list displays a reserved image area.
  portfolios: [
    {id:'portfolio-01',title:'PORTFOLIO 01',subtitle:'The Drape Series',image:'drape',status:'ILLUSTRATIVE STUDY',body:'A visual study of shape, drape and movement. The current illustration is a concept placeholder for this collection.',gallery:[]},
    {id:'portfolio-02',title:'PORTFOLIO 02',subtitle:'Tailored Nostalgia',image:'tailoring',status:'ILLUSTRATIVE STUDY',body:'A study of garment details, texture and proportion. The current illustration is a concept placeholder for this collection.',gallery:[]},
    {id:'portfolio-03',title:'PORTFOLIO 03',subtitle:'Collection title to come',status:'COMING SOON',body:'This collection is taking shape. Its work will appear here.',gallery:[]},
    {id:'portfolio-04',title:'PORTFOLIO 04',subtitle:'Collection title to come',status:'COMING SOON',body:'This collection is taking shape. Its work will appear here.',gallery:[]},
    {id:'portfolio-05',title:'PORTFOLIO 05',subtitle:'Collection title to come',status:'COMING SOON',body:'This collection is taking shape. Its work will appear here.',gallery:[]},
    {id:'portfolio-06',title:'PORTFOLIO 06',subtitle:'Collection title to come',status:'COMING SOON',body:'This collection is taking shape. Its work will appear here.',gallery:[]},
    {id:'portfolio-07',title:'PORTFOLIO 07',subtitle:'Collection title to come',status:'COMING SOON',body:'This collection is taking shape. Its work will appear here.',gallery:[]},
    {id:'portfolio-08',title:'PORTFOLIO 08',subtitle:'Collection title to come',status:'COMING SOON',body:'This collection is taking shape. Its work will appear here.',gallery:[]}
  ],
  stories: {
    about: {eyebrow: 'A NOTE FROM THE STUDIO', title: 'A curious spirit.<br>A considered eye.', body: 'JADE STUDIO is an independent online fashion design studio. This journal is a place to share our work, our references, and the details that catch our eye.', note: 'More studio stories will be added here.'},
    invitation: {eyebrow: 'YOU ARE INVITED', title: 'Come a little closer.', body: 'Welcome to JADE STUDIO. Browse the journal, look at the details, and stay for a while.', note: 'An open invitation to our world of fashion.', action: 'EXPLORE SELECTED WORK ↗'},
    contact: {eyebrow: 'CORRESPONDENCE', title: 'Let’s make<br>something.', body: 'For collaborations, projects and conversations.', note: 'Contact details coming soon. / 联系方式待补充。'},
    drape: {eyebrow: '01 / FASHION STUDY', title: 'The Drape Series', image: 'drape', body: 'A visual study of fabric in motion. Ivory folds meet a forest-green silhouette; drawn lines follow the weight and fall of the cloth.', note: 'Illustrative concept — sample imagery and copy for this first edition.'},
    tailoring: {eyebrow: '02 / DETAIL STUDY', title: 'Tailored Nostalgia', image: 'tailoring', body: 'An exploration of familiar shapes through ink, texture and proportion. A closer look at the gestures hidden in a garment.', note: 'Illustrative concept — sample imagery and copy for this first edition.'}
  }
};
