// Opt-in browser regression. No diagnostic UI in the user-facing page.
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
export async function checkJourney(stage){
 const report=document.createElement('pre');
 report.id='journey-check';
 report.style.cssText='position:fixed;bottom:8px;left:20px;z-index:100;background:#182318;color:white;padding:14px;font:12px monospace;pointer-events:none';
 document.body.append(report);
 const lines=[];
 const log=text=>{lines.push(text);report.textContent=lines.join('\n');};
 const move=async x=>{
  const rect=stage.getBoundingClientRect();
  stage.dispatchEvent(new PointerEvent('pointermove',{bubbles:true,clientX:rect.left+rect.width*x,clientY:Math.min(innerHeight*.6,rect.bottom-20),buttons:0,pointerId:7,pointerType:'mouse'}));
  await wait(55);
 };
 const until=async condition=>{for(let i=0;i<80;i++){if(condition())return;await wait(50);}throw Error('state timeout');};
 try{
  if(document.documentElement.scrollHeight<=innerHeight)throw Error('paper cannot scroll');
  scrollTo(0,300);await wait(100);
  if(scrollY<100)throw Error('vertical scrolling blocked');
  if(Number(stage.dataset.pageIndex)!==0)throw Error('vertical scrolling turned page');
  log('PASS · full-size paper scrolls vertically');
  scrollTo(0,0);
  const count=Number(stage.dataset.pageCount);
  const titles=[stage.dataset.project];
  for(let page=1;page<=count;page++){
   await move(.88);for(const x of [.80,.70,.60,.50,.40])await move(x);
   if(page===count&&!matchMedia('(prefers-reduced-motion: reduce)').matches){
    await until(()=>stage.dataset.view==='joining');
    const flying=document.querySelector('.paper-join');
    const start=flying.getBoundingClientRect().width;
    await wait(280);
    if(flying.getBoundingClientRect().width>=start*.9)throw Error('final paper does not visibly shrink');
    log('PASS · last full paper visibly shrinks during the handoff');
   }
   await until(()=>page<count?Number(stage.dataset.pageIndex)===page:stage.dataset.view==='river');
   if(page<count){titles.push(stage.dataset.project);log(`PASS · business ${page+1}/${count}`);}
  }
  if(new Set(titles).size!==6)throw Error('six distinct business columns missing');
  log('PASS · six distinct approved business columns');
  if(!document.querySelector('#paper-view').hidden)throw Error('old paper remains');
  const river=document.querySelector('#river-gallery');
  if(river.closest('[hidden]'))throw Error('river hidden');
  await until(()=>[...river.querySelectorAll('button')].some(b=>b.style.visibility==='visible'));
  log('PASS · final paper leaves, original river appears');
  const carried=river.querySelector('.carried-paper img');
  if(!carried||carried.naturalWidth!==1230||carried.naturalHeight!==705)throw Error('cover-only image missing from river');
  log('PASS · only the central cover continues as a river image');
  const card=[...river.querySelectorAll('button')].find(b=>b.style.visibility==='visible');
  const before=card.style.transform;await wait(400);
  if(card.style.transform===before)throw Error('river not moving at rest');
  log('PASS · river flows without mouse movement');
  if(document.documentElement.scrollHeight-innerHeight>innerHeight*2)throw Error('ending needs more than two viewport scrolls');
  scrollBy(0,innerHeight);scrollBy(0,innerHeight);await wait(150);
  if(Math.abs(scrollY+innerHeight-document.documentElement.scrollHeight)>3)throw Error('two scrolls do not reach the bottom');
  log('PASS · two downward viewport scrolls reach the bottom');
  if(document.querySelector('#contact-heading').getBoundingClientRect().top>=innerHeight)throw Error('contact unreachable');
  let printed=document.querySelectorAll('.print-letter.printed').length;
  if(printed<1||printed>=11)throw Error('title did not start typing letter by letter');
  await wait(1800);
  if(document.querySelectorAll('.print-letter.printed').length!==11)throw Error('title did not finish printing');
  const band=document.querySelector('.contact-band'),track=document.querySelector('.contact-track');
  if(getComputedStyle(band).backgroundColor!=='rgb(188, 184, 147)'||getComputedStyle(band).color!=='rgb(71, 67, 41)')throw Error('band colors differ from approved palette');
  const matrix=getComputedStyle(track).transform;await wait(350);
  if(getComputedStyle(track).transform===matrix)throw Error('contact strip is not moving');
  log('PASS · letter printing and Pale Jade moving CONTACT US strip');
  log('PASS · bilingual contact follows gallery');
  document.querySelector('.study-header a').click();await wait(150);
  if(stage.dataset.view!=='paper'||Number(stage.dataset.pageIndex)!==count-1)throw Error('return did not preserve last paper');
  log('PASS · return restores last business page');
  await move(.88);for(const x of [.80,.70,.60,.50,.40])await move(x);
  await until(()=>stage.dataset.view==='river');
  log('ALL JOURNEY CHECKS PASSED');
 }catch(error){log('FAIL · '+error.message);report.style.background='#7b1919';}
}
