import {quadMatrix} from './envelope-sequence.mjs';
import {mountEnvelope3D,prepareEnvelopeArt} from './envelope-three.mjs';
let template=null,active=false,generation=0,transitionModel=null,previousTitle='';
export function prepareEnvelope(){
 prepareEnvelopeArt().catch(()=>{});
 if(!template)template=fetch('contact.html').then(r=>{if(!r.ok)throw new Error('Contact page unavailable');return r.text();}).catch(()=>{template=null;return null;});
 return template;
}
export async function enterEnvelope({sheet,url}){
 if(active)return;
 active=true;const run=++generation;
 if(matchMedia('(prefers-reduced-motion: reduce)').matches){location.assign(url);return;}
 try{
  const html=await prepareEnvelope();if(run!==generation)return;if(!html){location.assign(url);return;}
  const doc=new DOMParser().parseFromString(html,'text/html'),rect=sheet.getBoundingClientRect();
  const source={left:Math.max(0,rect.left),top:Math.max(0,rect.top),width:Math.min(innerWidth,rect.right)-Math.max(0,rect.left),height:Math.min(innerHeight,rect.bottom)-Math.max(0,rect.top)};
  if(source.width<=0||source.height<=0){location.assign(url);return;}
  const half=source.height/2;
  const overlay=document.createElement('div');overlay.className='contact-page contact-transition';overlay.setAttribute('aria-hidden','true');overlay.inert=true;overlay.style.visibility='hidden';
  const backdrop=document.createElement('div');backdrop.className='contact-backdrop';overlay.append(backdrop);
  overlay.append(document.importNode(doc.querySelector('.work-header'),true),document.importNode(doc.querySelector('.correspondence-scene'),true));
  const paper=document.createElement('div');paper.className='transition-paper';
  Object.assign(paper.style,{left:source.left+'px',top:source.top+half+'px',width:source.width+'px',height:half+'px'});
  const clone=sheet.cloneNode(true);clone.removeAttribute('id');clone.querySelectorAll('[id]').forEach(node=>node.removeAttribute('id'));
  const originalNodes=[sheet,...sheet.querySelectorAll('*')],clonedNodes=[clone,...clone.querySelectorAll('*')];
  originalNodes.forEach((node,i)=>{const style=getComputedStyle(node);for(const prop of ['font-family','font-size','font-weight','line-height','letter-spacing','margin','padding','max-width','min-height','text-align'])clonedNodes[i].style.setProperty(prop,style.getPropertyValue(prop));});
  Object.assign(clone.style,{left:rect.left-source.left+'px',top:rect.top-source.top+'px',width:rect.width+'px',height:rect.height+'px'});
  const top=document.createElement('div');top.className='fold-panel top';
  const topContent=document.createElement('div');topContent.className='fold-content';topContent.append(clone);
  const bottom=document.createElement('div');bottom.className='fold-panel bottom';
  const bottomContent=document.createElement('div');bottomContent.className='fold-content';
  const bottomClone=clone.cloneNode(true);bottomClone.style.top=rect.top-source.top-half+'px';bottomContent.append(bottomClone);bottom.append(bottomContent);
  const reverse=document.createElement('div');reverse.className='fold-back';
  top.append(topContent,reverse);paper.append(bottom,top);overlay.append(paper);document.body.append(overlay);
  transitionModel=await mountEnvelope3D(overlay.querySelector('.envelope-scene'),{interactive:false,letterHidden:true,sealed:false});
  if(run!==generation){transitionModel?.dispose();transitionModel=null;return;}
  // The exact same pixels are used on the folding DOM back and the WebGL paper.
  const face=new Image();face.alt='Contact Us';face.src=transitionModel.letterImage();await face.decode();reverse.append(face);
  if(run!==generation)return;
  const quad=transitionModel.letterQuad().map(p=>({x:p.x-source.left,y:p.y-source.top-half}));
  const matrix=quadMatrix(source.width,half,quad);
  sheet.dataset.envelopeHidden='true';sheet.style.visibility='hidden';document.body.classList.add('contact-transitioning');overlay.style.visibility='visible';
  backdrop.animate([{opacity:0},{opacity:1}],{duration:360,fill:'forwards'});
  overlay.querySelector('.envelope-webgl').animate([{opacity:0},{opacity:1}],{duration:480,fill:'forwards'});
  // Only the upper half rotates about a horizontal crease. The lower half stays put.
  const fold=top.animate([{transform:'rotateX(0deg)'},{transform:'rotateX(-180deg)'}],{duration:520,fill:'forwards',easing:'cubic-bezier(.4,0,.2,1)'});
  const align=paper.animate([{transform:'matrix3d(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1)'},{transform:`matrix3d(${matrix.join(',')})`}],{duration:760,fill:'forwards',easing:'cubic-bezier(.3,0,.2,1)'});
  await Promise.all([fold.finished,align.finished]);if(run!==generation)return;
  // A pixel-matched handoff, not a fade into a different picture or a second flip.
  const sealed=transitionModel.insertAndSeal();paper.remove();await sealed;
  if(run!==generation)return;
  // Keep this exact canvas/camera/pose alive. A full navigation briefly showed
  // a differently sized CSS fallback and then rebuilt the mesh, causing a jump.
  previousTitle=document.title;
  const project=new URL(url,location.href).searchParams.get('project');
  overlay.querySelector('#contact-back').href=project?`work.html?project=${encodeURIComponent(project)}&from=contact`:'index.html#portfolio-index';
  document.body.classList.add('contact-active');
  for(const node of document.body.children){if(node!==overlay&&!node.inert){node.inert=true;node.dataset.envelopeInert='true';}}
  overlay.classList.add('contact-live');overlay.inert=false;overlay.removeAttribute('aria-hidden');
  history.pushState({jadeEnvelope:true},'',url);document.title='Contact Us — JADE STUDIO';
  transitionModel.setInteractive(true);
 }catch{if(run===generation)location.assign(url);}
}
function resetEnvelope(){
 generation++;active=false;transitionModel?.dispose();transitionModel=null;
 const overlay=document.querySelector('.contact-transition');overlay?.getAnimations({subtree:true}).forEach(a=>a.cancel());overlay?.remove();
 document.body.classList.remove('contact-transitioning');document.querySelectorAll('[data-envelope-hidden]').forEach(node=>{node.style.visibility='';delete node.dataset.envelopeHidden;});
 document.body.classList.remove('contact-active');document.querySelectorAll('[data-envelope-inert]').forEach(node=>{node.inert=false;delete node.dataset.envelopeInert;});
 if(previousTitle){document.title=previousTitle;previousTitle='';}
}
window.addEventListener('pagehide',resetEnvelope);
window.addEventListener('pageshow',event=>{if(event.persisted&&history.state?.jadeEnvelope)location.reload();else resetEnvelope();});
window.addEventListener('popstate',()=>{if(history.state?.jadeEnvelope)location.reload();else resetEnvelope();});
