export const clamp=(n,min=0,max=1)=>Math.min(max,Math.max(min,Number.isFinite(n)?n:0));
const smooth=n=>{const t=clamp(n);return t*t*(3-2*t);};
export function ringVertex(u,v,angle=0,{radius=10,height=4.8}={}){
 const theta=u*Math.PI*2+angle;
 return {x:radius*Math.sin(theta),y:(v-.5)*height,z:radius*Math.cos(theta)};
}
export function transitionPose(progress){
 const p=clamp(progress);
 return {gather:smooth(p/.36),squeeze:smooth((p-.28)/.48),glyph:smooth((p-.59)/.24),white:smooth((p-.78)/.22)};
}
const noise=(i,s)=>{const x=Math.sin(i*127.1+s*311.7)*43758.5453;return x-Math.floor(x);};
export function galleryPose(index,progress,aspect=1.6,reducedMotion=false){
 const layer=index%3,scale=[.22,.65,1.3][layer],direction=index%2?1:-1;
 const x=(noise(index,1)-.5)*1.22+(reducedMotion?0:direction*progress*(.1+layer*.15));
 const y=.32+noise(index,2)*4.15-progress*(reducedMotion?.8:.65+layer*.18);
 return {x:x*(aspect<.8?.83:1),y,z:layer,scale:scale*(aspect<.8?.79:1)};
}
export function easeScroll(current,target,reducedMotion=false,delta=16.67){
 if(reducedMotion||Math.abs(target-current)<.0001)return target;
 return current+(target-current)*(1-Math.exp(-Math.min(delta,80)/90));
}
export function galleryPosition(index,progress,aspect=1.6,reducedMotion=false,viewportWidth=1440,count=viewportWidth<=600?90:126,pointer={x:0,y:0},elapsed=0){
 const range=5;
 // Consecutive images advect together; cycling happens well beyond either edge.
 const pointerX=reducedMotion?0:clamp(pointer.x,-1,1),pointerY=reducedMotion?0:clamp(pointer.y,-1,1);
 const drift=reducedMotion?0:Math.max(0,Number.isFinite(elapsed)?elapsed:0)*.035;
 const rawX=index/count*range-progress*.85-pointerX*.36-drift;
 const x=((rawX+.8)%range+range)%range-.8;
 // Interleave depth independently of category so all nine subjects can be near.
 const z=(index+Math.floor(index/9))%3;
 const scale=[.34,.72,1.3][z]*(.94+noise(index,4)*.12)*(aspect<.8?.79:1);
 const center=.65+.40*x+pointerY*.02;
 // Small studies sit at the bank edges, visible around the larger foreground work.
 const bank=z===0?(index%2?-.17:.15):z===1?(index%2?-.035:.035):0;
 const y=center+bank+(noise(index,3)-.5)*.02;
 const relativeWidth=Math.min(Math.min(.19,240/viewportWidth)*scale*(aspect<.8?1.8:1),.28/(aspect*.68));
 const halfHeight=relativeWidth*aspect*.34;
 const opacity=smooth((x+relativeWidth/2)/.08)*smooth((1-x+relativeWidth/2)/.08)*smooth((1-y+halfHeight)/.08);
 return {x,y,z,scale,relativeWidth,opacity};
}
export function galleryExposure(index,elapsed=0,reducedMotion=false,artworkCount=18){
 const initial=index%artworkCount;
 if(reducedMotion)return {study:initial,opacity:1,blur:0,offsetX:0,offsetY:0};
 const period=7.5+noise(index,6)*4,clock=Math.max(0,Number.isFinite(elapsed)?elapsed:0)/period+noise(index,7);
 const cycle=Math.floor(clock),phase=clock-cycle;
 const opacity=smooth(phase/.20)*smooth((1-phase)/.28);
 const category=initial%9,variants=Math.ceil((artworkCount-category)/9);
 const study=category+((Math.floor(initial/9)+cycle)%variants)*9;
 return {study,opacity,blur:(1-opacity)*6,offsetX:(noise(index+cycle*127,8)-.5)*.17,offsetY:(noise(index+cycle*127,9)-.5)*.11};
}
export function createNavigation(){
 const history=[],state={view:'entrance',category:null,scroll:0,entering:false,returnPayload:null};
 return {state,beginEntry(){if(state.entering||state.view!=='entrance')return false;state.entering=true;return true;},
 finishEntry(){state.entering=false;state.view='gallery';},
 reset(){history.length=0;Object.assign(state,{view:'entrance',category:null,scroll:0,entering:false,returnPayload:null});},
 open(view,category,scroll,payload=null){history.push({view:state.view,category:state.category,scroll,payload});state.view=view;state.category=category;state.scroll=0;},
 back(){const previous=history.pop();if(previous){state.view=previous.view;state.category=previous.category;state.scroll=previous.scroll;state.returnPayload=previous.payload;}return state.view;}};
}
