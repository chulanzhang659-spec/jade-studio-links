import * as THREE from './assets/vendor/three.module.min.js';
import {ringVertex} from './arc-model.mjs?v=arc10';
import {loadOpeningArtworks} from './artwork.js?v=arc10';

export async function createArc(host,{onSelect=()=>{},onReady=()=>{},onError=()=>{}}={}){
 let renderer;
 try{renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,powerPreference:'low-power'});}catch(error){onError(error);throw error;}
 const scene=new THREE.Scene(),camera=new THREE.PerspectiveCamera(43,1,.1,100),group=new THREE.Group();
 scene.add(group);group.rotation.set(.25,0,-.19);camera.position.set(0,9,18);camera.lookAt(0,0,0);
 renderer.setPixelRatio(Math.min(devicePixelRatio,2));renderer.setClearColor(0x737541,0);renderer.outputColorSpace=THREE.SRGBColorSpace;
 renderer.domElement.setAttribute('aria-hidden','true');host.append(renderer.domElement);
 let artworks;
 try{artworks=await loadOpeningArtworks();}catch(error){renderer.dispose();renderer.domElement.remove();onError(error);throw error;}
 const meshes=[],textures=[];
 for(let index=0;index<9;index++){
  const cols=72,rows=8,positions=[],uvs=[],indices=[];
  for(let y=0;y<=rows;y++)for(let x=0;x<=cols;x++){
   const u=(index+x/cols)/9,p=ringVertex(u,y/rows,0);
   positions.push(p.x,p.y,p.z);uvs.push(x/cols,y/rows);
  }
  for(let y=0;y<rows;y++)for(let x=0;x<cols;x++){const a=y*(cols+1)+x,b=a+cols+1;indices.push(a,b,a+1,b,b+1,a+1);}
  const geometry=new THREE.BufferGeometry();geometry.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geometry.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geometry.setIndex(indices);geometry.computeVertexNormals();
  const texture=new THREE.CanvasTexture(artworks[index]);texture.colorSpace=THREE.SRGBColorSpace;texture.anisotropy=Math.min(4,renderer.capabilities.getMaxAnisotropy());textures.push(texture);
  const material=new THREE.MeshBasicMaterial({map:texture,side:THREE.DoubleSide,depthTest:true,depthWrite:true,toneMapped:false});
  material.onBeforeCompile=shader=>{shader.fragmentShader=shader.fragmentShader.replace('#include <map_fragment>',THREE.ShaderChunk.map_fragment.replace('texture2D( map, vMapUv )','texture2D( map, vec2( gl_FrontFacing ? vMapUv.x : 1.0 - vMapUv.x, vMapUv.y ) )'));};
  material.customProgramCacheKey=()=>'jade-readable-double-side';
  const mesh=new THREE.Mesh(geometry,material);mesh.userData.index=index;group.add(mesh);meshes.push(mesh);
 }
 const motion=matchMedia('(prefers-reduced-motion: reduce)');
 let frame=0,paused=false,disposed=false,selected=0,elapsed=0,last=performance.now(),pointer={x:0,y:0},reduced=motion.matches;
 const raycaster=new THREE.Raycaster(),mouse=new THREE.Vector2();
 function resize(){const w=host.clientWidth,h=host.clientHeight;renderer.setSize(w,h,false);camera.aspect=w/h;camera.fov=w/h<.8?59:43;camera.updateProjectionMatrix();if(paused)renderer.render(scene,camera);}
 const observer=new ResizeObserver(resize);observer.observe(host);resize();
 function projectedBounds(mesh){
  mesh.updateWorldMatrix(true,false);const pts=[];
  for(let y=0;y<=1;y++)for(let x=0;x<=12;x++){const p=ringVertex((mesh.userData.index+x/12)/9,y);const v=new THREE.Vector3(p.x,p.y,p.z).applyMatrix4(mesh.matrixWorld).project(camera);pts.push({x:(v.x*.5+.5)*innerWidth,y:(-.5*v.y+.5)*innerHeight});}
  const xs=pts.map(p=>p.x),ys=pts.map(p=>p.y);
  return {x:Math.min(...xs),y:Math.min(...ys),width:Math.max(...xs)-Math.min(...xs),height:Math.max(...ys)-Math.min(...ys),points:pts};
 }
 function choose(index){
  const mesh=meshes[index];selected=index;
  return {image:artworks[index],categoryIndex:index,index,sourceBounds:projectedBounds(mesh),images:[artworks[(index+8)%9],artworks[(index+1)%9]],artworks};
 }
 function pick(event,select=false){
  const rect=renderer.domElement.getBoundingClientRect();mouse.set((event.clientX-rect.left)/rect.width*2-1,-((event.clientY-rect.top)/rect.height)*2+1);raycaster.setFromCamera(mouse,camera);
  const hit=raycaster.intersectObjects(meshes,false)[0];renderer.domElement.style.cursor=hit?'pointer':'default';
  if(hit){selected=hit.object.userData.index;if(select)onSelect(choose(selected));}
 }
 function move(event){pointer.x=(event.clientX/innerWidth-.5);pointer.y=(event.clientY/innerHeight-.5);pick(event);}
 function click(event){pick(event,true);}
 host.addEventListener('pointermove',move);host.addEventListener('click',click);
 function render(now){
  if(paused||disposed)return;
  const dt=Math.min((now-last)/1000,.05);last=now;elapsed+=dt;
  const settle=reduced?1:Math.min(elapsed/1.25,1),ease=1-(1-settle)**3;
  group.rotation.y=-.16+(reduced?0:elapsed*.022)+(1-ease)*.42;
  group.rotation.x+=((.25+(reduced?0:pointer.y*.035))-group.rotation.x)*.04;group.rotation.z+=((-.19+(reduced?0:pointer.x*.035))-group.rotation.z)*.04;
  group.position.y=(1-ease)*-2;renderer.render(scene,camera);frame=reduced?0:requestAnimationFrame(render);
 }
 function pause(){paused=true;cancelAnimationFrame(frame);}
 function resume(){if(disposed)return;paused=false;last=performance.now();cancelAnimationFrame(frame);frame=requestAnimationFrame(render);}
 function motionChanged(event){reduced=event.matches;if(!paused)resume();}
 motion.addEventListener('change',motionChanged);
 resume();onReady(artworks);
 return {artworks,pause,resume,enter(index){pause();return choose(Number.isInteger(index)?index:selected);},reset(){elapsed=0;pointer={x:0,y:0};resume();},dispose(){disposed=true;pause();observer.disconnect();motion.removeEventListener('change',motionChanged);host.removeEventListener('pointermove',move);host.removeEventListener('click',click);meshes.forEach(m=>{m.geometry.dispose();m.material.dispose();});textures.forEach(t=>t.dispose());renderer.dispose();renderer.domElement.remove();}};
}
