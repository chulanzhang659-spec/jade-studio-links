import {CATEGORIES} from './categories.mjs?v=arc9';
import {loadArtworks,artworkURL} from './artwork.js?v=arc9';
import {createNavigation} from './arc-model.mjs?v=arc9';
import {playCompression} from './arc-transition.js?v=arc9';
import {createGallery} from './arc-gallery.js?v=arc9';
import {manifestoSVG} from './arc-typography.mjs?v=arc9';

function layoutManifesto(){document.getElementById('manifesto-type').innerHTML=manifestoSVG(innerWidth,innerHeight);}
layoutManifesto();window.addEventListener('resize',layoutManifesto);

const $=id=>document.getElementById(id),nav=createNavigation(),reduced=matchMedia('(prefers-reduced-motion: reduce)');
let arc=null,artworks=[],gallery=null,transition=null,menuFocus=null,activeDialog=null,disposed=false,currentDetailImage=null;
const status=message=>{$('status').textContent=message;};
const safeFocus=el=>{(el?.isConnected&&el.getClientRects().length?el:(activeDialog?$(activeDialog).querySelector('button'):$('menu-toggle'))).focus({preventScroll:true});};
function applyView(){const entered=nav.state.view!=='entrance';document.body.dataset.view=nav.state.view;$('studio').hidden=!entered;$('entrance').hidden=entered;$('back').hidden=!entered;}
function ensureGallery(){if(artworks.length&&!gallery)gallery=createGallery($('gallery'),{artworks,onSelect:openDetail});}
function finishEntry(){transition=null;nav.finishEntry();applyView();ensureGallery();scrollTo(0,0);$('manifesto').focus({preventScroll:true});status('JADE 工作室。向下滚动浏览概念研究。');}
function enter(selection){
 if(!nav.beginEntry())return;
 $('enter').disabled=true;arc?.pause();ensureGallery();
 const selected=selection??arc?.enter()??{image:artworks[0],images:[artworks[8],artworks[1]]};
 transition=playCompression({...selected,reducedMotion:reduced.matches||!selected.image,onComplete:finishEntry});
}
function closeMenu(restore=true){if(!$('menu').open)return;$('menu').close();document.body.classList.remove('dialog-open');if(restore)safeFocus(menuFocus);if(nav.state.view==='entrance')arc?.resume();}
function openMenu(){if(nav.state.entering)return;menuFocus=document.activeElement;arc?.pause();$('menu').showModal();document.body.classList.add('dialog-open');}
function openView(view){
 const previous=activeDialog;
 if(previous===view)return;
 nav.open(view,null,previous?$(previous).scrollTop:scrollY,{focus:document.activeElement,image:currentDetailImage});if(previous)$(previous).close();
 closeMenu(false);arc?.pause();activeDialog=view;document.body.classList.add('dialog-open');$(view).showModal();$(view).scrollTop=0;
}
function openDetail(index,image,source){
 const c=CATEGORIES[index];if(!c)return;
 openView('detail');renderDetail(index,image);
 $('detail').scrollTop=0;$('detail-title').focus({preventScroll:true});
}
function renderDetail(index,image){
 const c=CATEGORIES[index];nav.state.category=index;currentDetailImage=image??artworks[index];
 $('detail-number').textContent=`${c.id} / 09`;$('detail-title').replaceChildren(document.createTextNode(c.label));const english=document.createElement('span');english.textContent=c.english;$('detail-title').append(english);
 $('detail-description').textContent=c.description;$('detail-image').src=artworkURL(currentDetailImage);$('detail-image').alt=`${c.label} · JADE 概念研究，全幅画面`;
 $('detail-studies').replaceChildren();for(const offset of [9,1]){const study=(index+offset)%artworks.length,figure=document.createElement('figure'),img=document.createElement('img'),caption=document.createElement('figcaption');img.src=artworkURL(artworks[study]);img.alt=`${c.label} 的素材与构图研究`;caption.textContent=`STUDY ${String(study+1).padStart(2,'0')} / MATERIAL & COMPOSITION`;figure.append(img,caption);$('detail-studies').append(figure);}
 $('next-category').textContent=`${CATEGORIES[(index+1)%9].label} / Next direction ↗`;status(c.label+'，概念研究，非客户项目。');
}
function openContact(){openView('contact');}
function closeView(){
 if(!activeDialog)return;$(activeDialog).close();nav.back();const saved=nav.state.scroll,payload=nav.state.returnPayload;
 if(nav.state.view==='detail'||nav.state.view==='contact'){
  activeDialog=nav.state.view;if(activeDialog==='detail')renderDetail(nav.state.category,payload?.image);$(activeDialog).showModal();$(activeDialog).scrollTop=saved;requestAnimationFrame(()=>{$(activeDialog).scrollTop=saved;safeFocus(payload?.focus);});return;
 }
 activeDialog=null;document.body.classList.remove('dialog-open');applyView();
 scrollTo({top:saved,behavior:'instant'});requestAnimationFrame(()=>{scrollTo({top:saved,behavior:'instant'});gallery?.refresh();safeFocus(payload?.focus);});
 if(nav.state.view==='entrance')arc?.resume();
}
function reset(){
 transition?.cancel();transition=null;if(activeDialog){$(activeDialog).close();activeDialog=null;}closeMenu(false);document.body.classList.remove('dialog-open');nav.reset();applyView();$('enter').disabled=false;scrollTo(0,0);arc?.reset();$('home').focus({preventScroll:true});
}
function buildIndex(){
 for(const c of CATEGORIES){const button=document.createElement('button');button.type='button';button.className='category-link';button.innerHTML=`<small>${c.id}</small><strong>${c.label}</strong><span>${c.english}</span>`;button.addEventListener('click',()=>{if(artworks.length)openDetail(c.index);else{closeMenu();enter();}});$('category-index').append(button);}
}
function buildStamps(){
 for(const c of CATEGORIES){const button=document.createElement('button');button.type='button';button.className='stamp';button.setAttribute('aria-label',c.label+' · 查看概念研究');const img=document.createElement('img');img.src=artworkURL(artworks[c.index]);img.alt='';const span=document.createElement('span');span.textContent=c.label;const small=document.createElement('small');small.textContent=`JADE / ${c.id}`;button.append(img,span,small);button.addEventListener('click',()=>openDetail(c.index));$('stamps').append(button);}
}
function fallback(){
 const host=$('arc');host.replaceChildren();const field=document.createElement('div');field.className='arc-fallback';field.setAttribute('aria-hidden','true');for(let i=0;i<6;i++){const img=document.createElement('img');img.src=artworkURL(artworks[i]);img.alt='';field.append(img);}host.append(field);status('静态画面模式。使用 Explore the studio 或菜单浏览。');
}
$('enter').addEventListener('click',()=>enter());$('home').addEventListener('click',reset);$('back').addEventListener('click',reset);$('menu-toggle').addEventListener('click',openMenu);
$('menu-studio').addEventListener('click',()=>{closeMenu(false);if(nav.state.view==='entrance')enter();else{$('manifesto').scrollIntoView();$('manifesto').focus({preventScroll:true});}});
$('next-category').addEventListener('click',()=>openDetail((nav.state.category+1)%9));
document.querySelectorAll('[data-contact]').forEach(button=>button.addEventListener('click',openContact));
document.querySelectorAll('[data-close]').forEach(button=>button.addEventListener('click',()=>button.dataset.close==='menu'?closeMenu():closeView()));
for(const id of ['menu','detail','contact'])$(id).addEventListener('cancel',event=>{event.preventDefault();if(id==='menu')closeMenu();else closeView();});
document.querySelector('.skip').addEventListener('click',event=>{if(nav.state.view==='entrance'){event.preventDefault();enter();}});
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&nav.state.entering){transition?.cancel();transition=null;nav.reset();$('enter').disabled=false;arc?.resume();safeFocus($('enter'));}});
buildIndex();
async function initialize(){
 try{await Promise.allSettled([document.fonts.load('54px "La Belle Aurore"'),document.fonts.load('13px "Special Elite"')]);artworks=await loadArtworks();if(disposed)return;buildStamps();ensureGallery();const {createArc}=await import('./arc-renderer.js?v=arc9');arc=await createArc($('arc'),{onSelect:enter,onError:()=>{}});if(nav.state.view!=='entrance'||nav.state.entering)arc.pause();status('JADE。选择图像或 Explore the studio 进入。');}
 catch(error){if(artworks.length)fallback();else status('图像暂时无法载入。仍可使用菜单与工作室入口。');console.warn('JADE static fallback:',error.message);}
}
initialize();
document.addEventListener('visibilitychange',()=>{if(document.hidden)arc?.pause();else if(nav.state.view==='entrance'&&!nav.state.entering&&!$('menu').open)arc?.resume();});
function onPageHide(event){
 arc?.pause();
 if(event.persisted){if(nav.state.entering){transition?.cancel();transition=null;}return;}
 disposed=true;transition?.cancel();arc?.dispose();gallery?.dispose();
}
function onPageShow(event){
 if(!event.persisted||disposed)return;
 gallery?.refresh();
 if(nav.state.entering){finishEntry();return;}
 if(nav.state.view==='entrance'&&!activeDialog&&!$('menu').open)arc?.resume();
}
window.addEventListener('pagehide',onPageHide);
window.addEventListener('pageshow',onPageShow);
