// Opt-in regression for the shared contact handoff; never shown to normal visitors.
const wait=ms=>new Promise(resolve=>setTimeout(resolve,ms));
export async function checkContact(stage){
 const report=document.createElement('pre');
 report.style.cssText='position:fixed;bottom:8px;left:20px;z-index:100;background:#182318;color:white;padding:14px;font:12px monospace;pointer-events:none';
 document.body.append(report);
 const lines=[];
 const log=text=>{lines.push(text);report.textContent=lines.join('\n');};
 const until=async condition=>{for(let i=0;i<100;i++){if(condition())return;await wait(50);}throw Error('state timeout');};
 try{
  const initial=stage.dataset.pageIndex;
  for(let attempt=0;attempt<2;attempt++){
   document.querySelector('#contact-shortcut').click();
   if(!matchMedia('(prefers-reduced-motion: reduce)').matches){
    if(stage.dataset.view!=='joining')throw Error('shortcut skipped animation');
    const flying=document.querySelector('.paper-join');
    const width=flying.getBoundingClientRect().width;
    document.querySelector('#contact-shortcut').click();
    if(document.querySelectorAll('.paper-join').length!==1)throw Error('duplicate transition');
    await wait(280);
    if(flying.getBoundingClientRect().width>=width*.9)throw Error('cover did not shrink');
   }
   await until(()=>stage.dataset.view==='river');
   if(scrollY>2)throw Error('shortcut jumped below river');
   const carried=document.querySelector('.carried-paper img');
   await until(()=>carried?.naturalWidth===1230);
   if(carried.naturalHeight!==705)throw Error('whole page carried instead of cover');
   log('PASS · shortcut shrinks cover into river, stays at top');
   if(attempt===0)document.querySelector('.carried-paper').click();
   else document.querySelector('.study-header a').click();
   await wait(150);
   if(stage.dataset.view!=='paper'||stage.dataset.pageIndex!==initial)throw Error('return changed portfolio');
   log('PASS · return preserves current portfolio');
  }
  log('ALL CONTACT CHECKS PASSED');
 }catch(error){log('FAIL · '+error.message);report.style.background='#7b1919';}
}
